import { useState, useEffect } from 'react';
import { api } from '../api';

// Standalone fetch function for components that don't need the full hook
export const fetchData = async (endpoint) => {
  try {
    const response = await fetch(`http://localhost:8000${endpoint}`);
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Fetch error:', error);
    throw error;
  }
};

export function useApi(apiCall, dependencies = []) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchApiData = async () => {
    try {
      setLoading(true);
      setError(null);
      const result = await apiCall();
      setData(result);
      return result;
    } catch (err) {
      setError(err.message);
      console.error('API Error:', err);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    let isMounted = true;

    const loadData = async () => {
      try {
        const result = await fetchApiData();
        if (!isMounted) {
          // Reset state if component unmounted
          setData(null);
          setLoading(false);
        }
      } catch (err) {
        if (!isMounted) {
          setError(null);
          setLoading(false);
        }
      }
    };

    loadData();

    return () => {
      isMounted = false;
    };
  }, dependencies);

  return { data, loading, error, fetchData: fetchApiData };
}

export function useCommodities() {
  return useApi(() => api.getCommodities());
}

export function useRegions() {
  return useApi(() => api.getRegions());
}

export function useLatestPrices(filters = {}) {
  return useApi(() => api.getLatestPrices(filters), [JSON.stringify(filters)]);
}

export function usePriceTrends(filters = {}) {
  return useApi(() => api.getPriceTrends(filters), [JSON.stringify(filters)]);
}
