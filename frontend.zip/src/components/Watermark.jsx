import { useState, useEffect } from 'react';
import { api } from '../api';

export function Watermark() {
  const [licenseStatus, setLicenseStatus] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    checkLicenseStatus();
  }, []);

  const checkLicenseStatus = async () => {
    try {
      const response = await api.get('/license/status/');
      setLicenseStatus(response);
    } catch (error) {
      console.error('License check failed:', error);
      setLicenseStatus({
        licensed: false,
        trial: true,
        message: 'Trial Version - Activate License to Remove Watermark'
      });
    } finally {
      setLoading(false);
    }
  };

  // License system disabled - always return null to hide watermark
  return null;

  return (
    <>
      {/* Subtle professional watermark styles */}
      <style jsx>{`
        @keyframes gentle-glow {
          0%, 100% { 
            text-shadow: 0 0 3px rgba(220, 38, 38, 0.3);
          }
          50% { 
            text-shadow: 0 0 6px rgba(220, 38, 38, 0.5);
          }
        }
        
        @keyframes soft-pulse {
          0%, 100% { background-color: #dc2626; }
          50% { background-color: #b91c1c; }
        }
        
        .gentle-glow {
          animation: gentle-glow 3s ease-in-out infinite;
        }
        
        .soft-pulse {
          animation: soft-pulse 2s ease-in-out infinite;
        }
      `}</style>

      {/* Professional Floating Watermark */}
      <div className="fixed inset-0 pointer-events-none z-40 select-none">
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="transform -rotate-45 opacity-15 text-red-600">
            <div className="text-6xl font-bold mb-4 text-center gentle-glow">
              TRIAL VERSION
            </div>
            <div className="text-2xl text-center">
              Tanzania Crop Price System
            </div>
            <div className="text-lg text-center mt-2">
              Contact Developer for License
            </div>
          </div>
        </div>
        
        {/* Repeated watermarks */}
        <div className="absolute inset-0 grid grid-cols-3 grid-rows-3 gap-8 p-8">
          {[...Array(9)].map((_, i) => (
            <div key={i} className="flex items-center justify-center opacity-8">
              <div className="transform rotate-12 text-red-500 text-xl font-semibold">
                UNLICENSED-Bezaleel!
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Professional Top Banner */}
      <div className="fixed top-0 left-0 right-0 soft-pulse text-white text-center py-2 z-50 shadow-lg">
        <div className="flex items-center justify-center space-x-4 text-sm">
          <span className="font-semibold">🔒 {licenseStatus.message}</span>
          <span className="hidden md:inline">•</span>
          <span className="hidden md:inline">Contact developer to purchase license</span>
          <LicenseActivator onActivated={checkLicenseStatus} />
        </div>
      </div>

      {/* Push content down to account for banner */}
      <div className="h-10"></div>
    </>
  );
}

function LicenseActivator({ onActivated }) {
  const [showModal, setShowModal] = useState(false);
  const [licenseKey, setLicenseKey] = useState('');
  const [clientName, setClientName] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  const handleActivate = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessage('');

    try {
      const response = await api.post('/license/activate/', {
        license_key: licenseKey,
        client_name: clientName
      });

      if (response.success) {
        setMessage('License activated successfully! Page will refresh...');
        setTimeout(() => {
          onActivated();
          setShowModal(false);
          window.location.reload();
        }, 2000);
      } else {
        setMessage(response.message || 'Activation failed');
      }
    } catch (error) {
      setMessage(error.response?.data?.message || 'Activation failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <button
        onClick={() => setShowModal(true)}
        className="bg-white text-red-600 px-3 py-1 rounded-md text-xs font-semibold hover:bg-gray-100 border border-red-200"
      >
        Activate License
      </button>

      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-[100] p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-md w-full p-6">
            <h3 className="text-lg font-semibold mb-4 text-gray-900">
              Activate License
            </h3>
            
            <form onSubmit={handleActivate} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Client/Organization Name
                </label>
                <input
                  type="text"
                  value={clientName}
                  onChange={(e) => setClientName(e.target.value)}
                  placeholder="Tanzania Ministry of Agriculture"
                  className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 text-black"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  License Key
                </label>
                <input
                  type="text"
                  value={licenseKey}
                  onChange={(e) => setLicenseKey(e.target.value.toUpperCase())}
                  placeholder="AGRI-XXXX-XXXX-XXXX-XXXX"
                  className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono text-black"
                  required
                />
              </div>

              {message && (
                <div className={`text-sm p-3 rounded ${
                  message.includes('successfully') 
                    ? 'bg-green-100 text-green-700' 
                    : 'bg-red-100 text-red-700'
                }`}>
                  {message}
                </div>
              )}

              <div className="flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 text-gray-600 border border-gray-300 rounded-md hover:bg-gray-50"
                  disabled={loading}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50"
                >
                  {loading ? 'Activating...' : 'Activate'}
                </button>
              </div>
            </form>

            <div className="mt-4 pt-4 border-t text-xs text-gray-500 space-y-2">
              <p>Contact the developer to purchase a license key.</p>
              <p className="mt-1">Phone: +255757047012</p>
              
              {/* Demo License Link */}
              <div className="mt-3 p-2 bg-blue-50 rounded border border-blue-200">
                <p className="text-blue-700 font-medium mb-1">Need a demo license?</p>
                <a 
                  href="/license-admin" 
                  target="_blank"
                  className="inline-block bg-blue-600 text-white px-3 py-1 rounded text-xs hover:bg-blue-700 transition-colors"
                >
                  🔑 Generate Demo License (3 min)
                </a>
                <p className="text-blue-600 text-xs mt-1">Get a 3-minute demo license to test the system</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
