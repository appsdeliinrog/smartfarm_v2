import { useState, useEffect } from 'react';
import { Modal } from './common/Modal';
import { PriceChart } from './PriceChart';
import { api } from '../api';
import { formatPrice } from '../utils/format';
import { convertPrice, getUnitDisplayText } from '../utils/priceUtils';
import { TrendingUp, TrendingDown, Minus, Calendar, MapPin, Package } from 'lucide-react';

export function PriceHistoryModal({ 
  isOpen, 
  onClose, 
  commodityId, 
  commodityName, 
  marketId, 
  marketName, 
  regionName,
  priceUnit = 'kg',
  currentPrice = null 
}) {
  const [priceHistory, setPriceHistory] = useState([]);
  const [statistics, setStatistics] = useState(null);
  const [loading, setLoading] = useState(false);
  const [timeRange, setTimeRange] = useState(90); // Default to 90 days

  useEffect(() => {
    if (isOpen && commodityId && marketId) {
      fetchPriceHistory();
    }
  }, [isOpen, commodityId, marketId, timeRange]);

  const fetchPriceHistory = async () => {
    setLoading(true);
    try {
      // Fetch price trends for specific commodity and market
      const trendData = await api.getPriceTrends({
        commodity: commodityId,
        market: marketId,
        days: timeRange
      });

      setPriceHistory(trendData || []);

      // Calculate statistics from the data
      if (trendData && trendData.length > 0) {
        const prices = trendData.map(item => {
          const minPrice = parseFloat(item.avg_min_price || 0);
          const maxPrice = parseFloat(item.avg_max_price || 0);
          return (minPrice + maxPrice) / 2;
        }).filter(price => price > 0);

        if (prices.length > 0) {
          const minPrice = Math.min(...prices);
          const maxPrice = Math.max(...prices);
          const avgPrice = prices.reduce((sum, p) => sum + p, 0) / prices.length;
          const firstPrice = prices[prices.length - 1];
          const lastPrice = prices[0];
          const priceChange = lastPrice - firstPrice;
          const priceChangePercent = firstPrice > 0 ? (priceChange / firstPrice) * 100 : 0;

          setStatistics({
            minPrice,
            maxPrice,
            avgPrice,
            priceChange,
            priceChangePercent,
            dataPoints: trendData.length,
            trend: priceChangePercent > 0 ? 'up' : priceChangePercent < 0 ? 'down' : 'neutral'
          });
        }
      }
    } catch (error) {
      console.error('Error fetching price history:', error);
      setPriceHistory([]);
      setStatistics(null);
    } finally {
      setLoading(false);
    }
  };

  const getTrendIcon = (trend) => {
    if (trend === 'up') return <TrendingUp className="h-4 w-4 text-green-500" />;
    if (trend === 'down') return <TrendingDown className="h-4 w-4 text-red-500" />;
    return <Minus className="h-4 w-4 text-gray-400" />;
  };

  const getTrendColor = (trend) => {
    if (trend === 'up') return 'text-green-600';
    if (trend === 'down') return 'text-red-600';
    return 'text-gray-500';
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Price History Analysis" size="xl">
      <div className="space-y-6">
        {/* Header Information */}
        <div className="bg-gradient-to-r from-green-50 to-blue-50 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Package className="h-5 w-5 text-green-600" />
                <h3 className="text-lg font-semibold text-gray-900">{commodityName}</h3>
              </div>
              <div className="flex items-center gap-4 text-sm text-gray-600">
                <div className="flex items-center gap-1">
                  <MapPin className="h-4 w-4" />
                  <span>{marketName}, {regionName}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Calendar className="h-4 w-4" />
                  <span>Last {timeRange} days</span>
                </div>
              </div>
            </div>
            
            {/* Current Price Display */}
            {currentPrice && (
              <div className="text-right">
                <div className="text-sm text-gray-500">Current Price</div>
                <div className="text-xl font-semibold text-gray-900">
                  {formatPrice(convertPrice(currentPrice.avg, priceUnit), 'TSh')} {getUnitDisplayText(priceUnit)}
                </div>
                <div className="text-xs text-gray-500">
                  {formatDate(currentPrice.date)}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Time Range Selector */}
        <div className="flex items-center gap-4">
          <label className="text-sm font-medium text-gray-700">Time Range:</label>
          <div className="flex gap-2">
            {[30, 60, 90, 180, 365].map((days) => (
              <button
                key={days}
                onClick={() => setTimeRange(days)}
                className={`px-3 py-1 text-sm rounded-md transition-colors ${
                  timeRange === days
                    ? 'bg-green-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {days}d
              </button>
            ))}
          </div>
        </div>

        {/* Statistics Cards */}
        {statistics && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-white border border-gray-200 rounded-lg p-4">
              <div className="flex items-center gap-2">
                <div className="text-sm text-gray-500">Average Price</div>
              </div>
              <div className="text-xl font-semibold text-gray-900">
                {formatPrice(convertPrice(statistics.avgPrice, priceUnit), 'TSh')}
              </div>
              <div className="text-xs text-gray-500">{getUnitDisplayText(priceUnit)}</div>
            </div>

            <div className="bg-white border border-gray-200 rounded-lg p-4">
              <div className="flex items-center gap-2">
                <div className="text-sm text-gray-500">Price Change</div>
                {getTrendIcon(statistics.trend)}
              </div>
              <div className={`text-xl font-semibold ${getTrendColor(statistics.trend)}`}>
                {statistics.trend !== 'neutral' && (statistics.trend === 'up' ? '+' : '')}
                {Math.abs(statistics.priceChangePercent).toFixed(1)}%
              </div>
              <div className="text-xs text-gray-500">
                {formatPrice(convertPrice(Math.abs(statistics.priceChange), priceUnit), 'TSh')} change
              </div>
            </div>

            <div className="bg-white border border-gray-200 rounded-lg p-4">
              <div className="text-sm text-gray-500">Highest Price</div>
              <div className="text-xl font-semibold text-red-600">
                {formatPrice(convertPrice(statistics.maxPrice, priceUnit), 'TSh')}
              </div>
              <div className="text-xs text-gray-500">{getUnitDisplayText(priceUnit)}</div>
            </div>

            <div className="bg-white border border-gray-200 rounded-lg p-4">
              <div className="text-sm text-gray-500">Lowest Price</div>
              <div className="text-xl font-semibold text-green-600">
                {formatPrice(convertPrice(statistics.minPrice, priceUnit), 'TSh')}
              </div>
              <div className="text-xs text-gray-500">{getUnitDisplayText(priceUnit)}</div>
            </div>
          </div>
        )}

        {/* Price Chart */}
        <div className="bg-white border border-gray-200 rounded-lg p-6">
          <h4 className="text-lg font-medium text-gray-900 mb-4">Price Trend Chart</h4>
          {loading ? (
            <div className="flex items-center justify-center h-64">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600"></div>
            </div>
          ) : priceHistory.length > 0 ? (
            <div className="h-64">
              <PriceChart
                commodityId={commodityId}
                marketId={marketId}
                days={timeRange}
                priceUnit={priceUnit}
                chartType="line"
              />
            </div>
          ) : (
            <div className="flex items-center justify-center h-64 text-gray-500">
              <div className="text-center">
                <Package className="h-12 w-12 mx-auto mb-2 text-gray-400" />
                <div>No price data available for this period</div>
                <div className="text-sm">Try selecting a different time range</div>
              </div>
            </div>
          )}
        </div>

        {/* Recent Price Points Table */}
        {priceHistory.length > 0 && (
          <div className="bg-white border border-gray-200 rounded-lg p-6">
            <h4 className="text-lg font-medium text-gray-900 mb-4">Recent Price Points</h4>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Date
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Min Price
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Max Price
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Avg Price
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {priceHistory.slice(0, 10).map((item, index) => {
                    const minPrice = parseFloat(item.avg_min_price || 0);
                    const maxPrice = parseFloat(item.avg_max_price || 0);
                    const avgPrice = (minPrice + maxPrice) / 2;
                    
                    return (
                      <tr key={index} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {formatDate(item.date)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {formatPrice(convertPrice(minPrice, priceUnit), 'TSh')}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {formatPrice(convertPrice(maxPrice, priceUnit), 'TSh')}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                          {formatPrice(convertPrice(avgPrice, priceUnit), 'TSh')}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </Modal>
  );
}
