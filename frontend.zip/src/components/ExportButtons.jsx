import { useState } from 'react';
import { exportToPDF, exportToCSV, exportChartAsImage, saveComparison, getSavedComparisons } from '../utils/exportUtils';

export function ExportButtons({ 
  comparisonData, 
  selectedCommodity,
  selectedMarkets, 
  commodities,
  markets,
  priceUnit
}) {
  const [isExporting, setIsExporting] = useState(false);
  const [showSaveModal, setShowSaveModal] = useState(false);

  // Get commodity name from commodities array
  const getCommodityName = () => {
    const commodity = commodities.find(c => c.id == selectedCommodity);
    return commodity ? commodity.name : 'Unknown Commodity';
  };

  const handleExportPDF = async () => {
    setIsExporting(true);
    try {
      const commodityName = getCommodityName();
      await exportToPDF(comparisonData, selectedCommodity, commodityName, priceUnit);
    } catch (error) {
      console.error('Error exporting PDF:', error);
      alert('Error exporting PDF. Please try again.');
    } finally {
      setIsExporting(false);
    }
  };

  const handleExportCSV = () => {
    setIsExporting(true);
    try {
      const commodityName = getCommodityName();
      exportToCSV(comparisonData, commodityName, priceUnit);
    } catch (error) {
      console.error('Error exporting CSV:', error);
      alert('Error exporting CSV. Please try again.');
    } finally {
      setIsExporting(false);
    }
  };

  const handleExportChart = async (chartType) => {
    setIsExporting(true);
    try {
      const chartId = `${chartType}-chart`;
      const commodityName = getCommodityName();
      await exportChartAsImage(chartId, `${commodityName}-${chartType}-chart`);
    } catch (error) {
      console.error('Error exporting chart:', error);
      alert('Error exporting chart. Please try again.');
    } finally {
      setIsExporting(false);
    }
  };

  const handleSaveComparison = () => {
    try {
      const commodityName = getCommodityName();
      const saved = saveComparison(comparisonData, commodityName, selectedMarkets, selectedCommodity);
      setShowSaveModal(false);
      alert(`Comparison saved as "${saved.name}"`);
    } catch (error) {
      console.error('Error saving comparison:', error);
      alert('Error saving comparison. Please try again.');
    }
  };

  return (
    <>
      <div className="bg-white rounded-lg shadow-sm p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">📤 Export & Save Options</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* PDF Export */}
          <button
            onClick={handleExportPDF}
            disabled={isExporting}
            className="flex items-center justify-center px-4 py-3 border border-gray-300 rounded-md shadow-sm bg-white text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <span className="mr-2">📄</span>
            Export PDF Report
          </button>

          {/* CSV Export */}
          <button
            onClick={handleExportCSV}
            disabled={isExporting}
            className="flex items-center justify-center px-4 py-3 border border-gray-300 rounded-md shadow-sm bg-white text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <span className="mr-2">📊</span>
            Export CSV Data
          </button>

          {/* Save Comparison */}
          <button
            onClick={() => setShowSaveModal(true)}
            disabled={isExporting}
            className="flex items-center justify-center px-4 py-3 border border-green-300 rounded-md shadow-sm bg-green-50 text-sm font-medium text-green-700 hover:bg-green-100 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <span className="mr-2">💾</span>
            Save Comparison
          </button>

          {/* Chart Export Dropdown */}
          <div className="relative">
            <select
              onChange={(e) => {
                if (e.target.value) {
                  handleExportChart(e.target.value);
                  e.target.value = '';
                }
              }}
              disabled={isExporting}
              className="block w-full px-4 py-3 border border-gray-300 rounded-md shadow-sm bg-white text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <option value="">🖼️ Export Charts</option>
              <option value="price-comparison">Price Comparison Chart</option>
              <option value="profit-margin">Profit Margin Chart</option>
              <option value="volatility">Volatility Chart</option>
            </select>
          </div>
        </div>

        {/* Export Status */}
        {isExporting && (
          <div className="mt-4 flex items-center justify-center">
            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-green-500 mr-2"></div>
            <span className="text-sm text-gray-600">Exporting...</span>
          </div>
        )}

        {/* Export Info */}
        <div className="mt-4 text-xs text-gray-500">
          <p>💡 <strong>PDF Report:</strong> Professional analysis with charts and recommendations</p>
          <p>📊 <strong>CSV Data:</strong> Raw data for spreadsheet analysis</p>
          <p>💾 <strong>Save:</strong> Quick access to this comparison later</p>
          <p>🖼️ <strong>Charts:</strong> High-quality images for presentations</p>
        </div>
      </div>

      {/* Save Modal */}
      {showSaveModal && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <div className="mt-3">
              <h3 className="text-lg font-medium text-gray-900 mb-4">💾 Save Comparison</h3>
              <p className="text-sm text-gray-600 mb-4">
                Save this comparison to quickly access it later. You can save up to 10 recent comparisons.
              </p>
              
              <div className="bg-gray-50 p-3 rounded-md mb-4">
                <p className="text-sm font-medium text-gray-700">Comparison Details:</p>
                <p className="text-sm text-gray-600">Commodity: {getCommodityName()}</p>
                <p className="text-sm text-gray-600">Markets: {selectedMarkets.length} selected</p>
                <p className="text-sm text-gray-600">Best Profit: {comparisonData.summary?.max_arbitrage ? 
                  new Intl.NumberFormat('en-TZ', {
                    style: 'currency',
                    currency: 'TZS',
                    minimumFractionDigits: 0,
                  }).format(priceUnit === '100kg' ? comparisonData.summary.max_arbitrage * 100 : comparisonData.summary.max_arbitrage)
                  : 'N/A'} per {priceUnit}</p>
              </div>

              <div className="flex justify-end space-x-3">
                <button
                  onClick={() => setShowSaveModal(false)}
                  className="px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-500"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSaveComparison}
                  className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500"
                >
                  💾 Save Comparison
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
