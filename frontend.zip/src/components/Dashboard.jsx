import { useState, useEffect } from 'react';
import { StatsCard } from './StatsCard';
import { CommodityAnalysisModal } from './CommodityAnalysisModal';
import { api } from '../api';
import { convertPrice, getUnitDisplayText } from '../utils/priceUtils';

export function Dashboard({ priceUnit = 'kg' }) {
  const [stats, setStats] = useState({
    totalCommodities: 0,
    totalMarkets: 0,
    averagePrice: 0,
    priceChange: 0,
  });
  const [loading, setLoading] = useState(true);
  const [showCommodityModal, setShowCommodityModal] = useState(false);

  useEffect(() => {
    const fetchStats = async () => {
      setLoading(true);
      try {
        const [commoditiesRes, marketsRes, summaryRes] = await Promise.all([
          api.getCommodities(),
          api.getMarkets(),
          api.getPriceSummary(),
        ]);

        // Calculate overall average price from the summary data
        let totalPrice = 0;
        let priceCount = 0;
        
        summaryRes.forEach(item => {
          if (item.min_price && item.max_price) {
            const minPrice = parseFloat(item.min_price);
            const maxPrice = parseFloat(item.max_price);
            if (!isNaN(minPrice) && !isNaN(maxPrice)) {
              totalPrice += (minPrice + maxPrice) / 2;
              priceCount++;
            }
          }
        });

        const averagePrice = priceCount > 0 ? totalPrice / priceCount : 0;

        setStats({
          totalCommodities: commoditiesRes?.count || commoditiesRes?.results?.length || 0,
          totalMarkets: marketsRes?.count || marketsRes?.results?.length || 0,
          averagePrice: averagePrice,
          priceChange: 0, // We don't have price change data from this API
        });
      } catch (error) {
        console.error('Error fetching dashboard stats:', error);
        // Set default values on error
        setStats({
          totalCommodities: 0,
          totalMarkets: 0,
          averagePrice: 0,
          priceChange: 0,
        });
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
  }, []);

  if (loading) {
    return (
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="bg-white overflow-hidden shadow rounded-lg animate-pulse">
            <div className="p-5">
              <div className="h-4 bg-gray-200 rounded mb-2"></div>
              <div className="h-8 bg-gray-200 rounded"></div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <>
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
        <StatsCard
          title="Total Commodities"
          value={stats.totalCommodities}
          trend="neutral"
          clickable={true}
          onClick={() => setShowCommodityModal(true)}
        />
        <StatsCard
          title="Active Markets"
          value={stats.totalMarkets}
          trend="neutral"
        />
        <StatsCard
          title={`Average Price ${getUnitDisplayText(priceUnit)}`}
          value={convertPrice(stats.averagePrice, priceUnit)}
          trend={stats.priceChange > 0 ? 'up' : stats.priceChange < 0 ? 'down' : 'neutral'}
          trendValue={Math.abs(stats.priceChange)}
          unit="TSh"
        />
        <StatsCard
          title="Price Observations"
          value="4,700+"
          trend="neutral"
        />
      </div>

      {/* Commodity Analysis Modal */}
      <CommodityAnalysisModal
        isOpen={showCommodityModal}
        onClose={() => setShowCommodityModal(false)}
        priceUnit={priceUnit}
      />
    </>
  );
}
