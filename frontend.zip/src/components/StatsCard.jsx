import { TrendingUp, TrendingDown, Minus } from 'lucide-react';
import { formatPrice } from '../utils/format';

export function StatsCard({ title, value, trend, trendValue, unit = 'TSh', onClick, clickable = false }) {
  const getTrendIcon = () => {
    if (trend === 'up') return <TrendingUp className="h-4 w-4 text-green-500" />;
    if (trend === 'down') return <TrendingDown className="h-4 w-4 text-red-500" />;
    return <Minus className="h-4 w-4 text-gray-400" />;
  };

  const getTrendColor = () => {
    if (trend === 'up') return 'text-green-600';
    if (trend === 'down') return 'text-red-600';
    return 'text-gray-500';
  };

  return (
    <div 
      className={`bg-white overflow-hidden shadow rounded-lg ${clickable ? 'cursor-pointer hover:shadow-md hover:bg-gray-50 transition-all duration-200' : ''}`}
      onClick={clickable ? onClick : undefined}
    >
      <div className="p-5">
        <div className="flex items-center">
          <div className="flex-shrink-0">
            {getTrendIcon()}
          </div>
          <div className="ml-5 w-0 flex-1">
            <dl>
              <dt className="text-sm font-medium text-gray-500 truncate">
                {title}
              </dt>
              <dd className="flex items-baseline">
                <div className="text-2xl font-semibold text-gray-900">
                  {typeof value === 'number' ? formatPrice(value, unit) : value}
                </div>
                {trendValue && (
                  <div className={`ml-2 flex items-baseline text-sm font-semibold ${getTrendColor()}`}>
                    {trend === 'up' ? '+' : trend === 'down' ? '-' : ''}
                    {Math.abs(trendValue)}%
                  </div>
                )}
              </dd>
            </dl>
          </div>
        </div>
      </div>
    </div>
  );
}
