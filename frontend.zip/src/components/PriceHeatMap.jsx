import React, { useState, useEffect } from 'react';
import { fetchData } from '../hooks/useApi';

const PriceHeatMap = ({ priceUnit }) => {
  const [commodities, setCommodities] = useState([]);
  const [selectedCommodity, setSelectedCommodity] = useState('');
  const [regionData, setRegionData] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadCommodities();
  }, []);

  useEffect(() => {
    if (selectedCommodity) {
      loadRegionPrices();
    }
  }, [selectedCommodity, priceUnit]);

  const loadCommodities = async () => {
    try {
      const data = await fetchData('/api/commodities/');
      setCommodities(data.results || data);
      if ((data.results || data).length > 0) {
        setSelectedCommodity((data.results || data)[0].id);
      }
    } catch (error) {
      console.error('Error loading commodities:', error);
    }
  };

  const loadRegionPrices = async () => {
    if (!selectedCommodity) return;
    
    setLoading(true);
    try {
      // First, get all price observations for the selected commodity
      const data = await fetchData(`/api/price-observations/?commodity=${selectedCommodity}&ordering=-date&limit=1000`);
      
      // Group by region and calculate average prices
      const regionGroups = {};
      const observations = data.results || data;
      
      console.log('Raw observations:', observations);
      console.log('Sample observation structure:', observations[0]);
      
      observations.forEach(obs => {
        console.log('Processing obs:', {
          region_name: obs.region_name,
          market_name: obs.market_name,
          market: obs.market,
          min_price: obs.min_price,
          max_price: obs.max_price,
          price: obs.price
        });
        
        // Extract region name from different possible fields
        const regionName = obs.region_name || 
                          obs.market?.region_name || 
                          obs.market_region || 
                          (obs.market_name && obs.market_name.includes(' - ') 
                            ? obs.market_name.split(' - ')[1] 
                            : 'Unknown Region');
        
        console.log('Extracted region name:', regionName);
        
        const marketName = obs.market_name || obs.market?.name || 'Unknown Market';
        
        if (!regionGroups[regionName]) {
          regionGroups[regionName] = {
            region: regionName,
            prices: [],
            markets: new Set(),
            observations: []
          };
        }
        
        // Get price based on selected unit
        let price = 0;
        console.log('Available price fields:', {
          min_price_per_kg: obs.min_price_per_kg,
          min_price: obs.min_price,
          min_price_per_100kg: obs.min_price_per_100kg,
          max_price: obs.max_price,
          price: obs.price
        });
        
        // The main price field is 'price' - use it for both units
        price = parseFloat(obs.price || obs.min_price || obs.max_price || 0);
        
        console.log('Extracted price:', price, 'TZS/kg from database, for display unit:', priceUnit);
        
        // Convert price if necessary
        if (price > 0) {
          // The database stores prices per kg (e.g., 900, 1000, 2300 TZS/kg)
          // Convert based on the selected display unit
          if (priceUnit === '100kg') {
            price = price * 100; // Convert from per kg to per 100kg for display
          }
          // If priceUnit is 'kg', use price as-is since it's already per kg
          
          console.log('Final converted price:', price, 'for unit:', priceUnit);
          
          regionGroups[regionName].prices.push(price);
          regionGroups[regionName].markets.add(marketName);
          regionGroups[regionName].observations.push(obs);
        }
      });
      
      console.log('Region groups after processing:', regionGroups);
      console.log('Number of regions found:', Object.keys(regionGroups).length);
      
      // Calculate statistics for each region
      const processedRegions = Object.values(regionGroups)
        .filter(region => region.prices.length > 0)
        .map(region => {
          const prices = region.prices;
          const avgPrice = prices.reduce((sum, p) => sum + p, 0) / prices.length;
          const minPrice = Math.min(...prices);
          const maxPrice = Math.max(...prices);
          
          return {
            region: region.region,
            avgPrice: Math.round(avgPrice),
            minPrice: Math.round(minPrice),
            maxPrice: Math.round(maxPrice),
            marketCount: region.markets.size,
            observationCount: region.observations.length,
            priceRange: Math.round(maxPrice - minPrice)
          };
        })
        .sort((a, b) => b.avgPrice - a.avgPrice); // Sort by highest average price
      
      console.log('Processed regions:', processedRegions); // Debug log
      setRegionData(processedRegions);
      
    } catch (error) {
      console.error('Error loading region prices:', error);
      setRegionData([]);
    }
    setLoading(false);
  };

  const getPriceIntensity = (price, maxPrice) => {
    if (maxPrice === 0) return 0;
    return (price / maxPrice) * 100;
  };

  const getHeatColor = (intensity) => {
    if (intensity >= 80) return 'bg-red-600 text-white';
    if (intensity >= 60) return 'bg-red-400 text-white';
    if (intensity >= 40) return 'bg-yellow-400 text-gray-900';
    if (intensity >= 20) return 'bg-green-400 text-gray-900';
    return 'bg-green-200 text-gray-700';
  };

  const getIntensityLabel = (intensity) => {
    if (intensity >= 80) return 'Very High';
    if (intensity >= 60) return 'High';
    if (intensity >= 40) return 'Medium';
    if (intensity >= 20) return 'Low';
    return 'Very Low';
  };

  const selectedCommodityName = commodities.find(c => c.id === parseInt(selectedCommodity))?.name || '';
  const maxPrice = Math.max(...regionData.map(r => r.avgPrice), 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Regional Price Heat Map</h2>
          <p className="text-gray-600">Visual comparison of commodity prices across regions</p>
        </div>
        
        {/* Commodity Selector */}
        <div className="flex flex-col sm:flex-row gap-2">
          <select
            value={selectedCommodity}
            onChange={(e) => setSelectedCommodity(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
          >
            <option value="">Select Commodity</option>
            {commodities.map(commodity => (
              <option key={commodity.id} value={commodity.id}>
                {commodity.name}
              </option>
            ))}
          </select>
          <div className="text-sm text-gray-500 self-center">
            Prices per {priceUnit}
          </div>
        </div>
      </div>

      {/* Legend */}
      <div className="bg-white rounded-lg border p-4">
        <h3 className="font-medium text-gray-900 mb-3">Price Level Legend</h3>
        <div className="flex flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-red-600 rounded"></div>
            <span className="text-sm">Very High (80-100%)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-red-400 rounded"></div>
            <span className="text-sm">High (60-80%)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-yellow-400 rounded"></div>
            <span className="text-sm">Medium (40-60%)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-green-400 rounded"></div>
            <span className="text-sm">Low (20-40%)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-green-200 rounded"></div>
            <span className="text-sm">Very Low (0-20%)</span>
          </div>
        </div>
      </div>

      {/* Heat Map Grid */}
      <div className="bg-white rounded-lg border">
        <div className="p-6 border-b">
          <h3 className="text-lg font-medium text-gray-900">
            {selectedCommodityName} Prices by Region
          </h3>
          {loading && <p className="text-sm text-gray-500 mt-1">Loading regional data...</p>}
        </div>

        {loading ? (
          <div className="p-8 text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600 mx-auto"></div>
            <p className="mt-2 text-gray-500">Loading heat map data...</p>
          </div>
        ) : regionData.length === 0 ? (
          <div className="p-8 text-center text-gray-500">
            {selectedCommodity ? 'No price data available for this commodity' : 'Please select a commodity to view the heat map'}
          </div>
        ) : (
          <div className="p-6">
            {/* Grid Layout */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {regionData.map((region, index) => {
                const intensity = getPriceIntensity(region.avgPrice, maxPrice);
                const colorClass = getHeatColor(intensity);
                
                return (
                  <div
                    key={region.region}
                    className={`p-4 rounded-lg border-2 transition-all duration-200 hover:scale-105 hover:shadow-lg ${colorClass}`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium text-sm">{region.region}</h4>
                      <span className="text-xs opacity-75">#{index + 1}</span>
                    </div>
                    
                    <div className="space-y-1">
                      <div className="text-lg font-bold">
                        {region.avgPrice.toLocaleString(undefined, {
                          minimumFractionDigits: 0,
                          maximumFractionDigits: 0
                        })} TZS
                      </div>
                      
                      <div className="text-xs opacity-75">
                        Range: {region.minPrice.toLocaleString()} - {region.maxPrice.toLocaleString()}
                      </div>
                      
                      <div className="flex justify-between text-xs opacity-75">
                        <span>{region.marketCount} market{region.marketCount !== 1 ? 's' : ''}</span>
                        <span>{getIntensityLabel(intensity)}</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Summary Stats */}
            <div className="mt-6 grid grid-cols-2 md:grid-cols-4 gap-4 pt-6 border-t">
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">
                  {regionData.length}
                </div>
                <div className="text-sm text-gray-500">Regions</div>
              </div>
              
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-600">
                  {maxPrice.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                </div>
                <div className="text-sm text-gray-500">Highest Price (TZS)</div>
              </div>
              
              <div className="text-center">
                <div className="text-2xl font-bold text-orange-600">
                  {regionData.length > 0 
                    ? Math.min(...regionData.map(r => r.avgPrice)).toLocaleString(undefined, { maximumFractionDigits: 0 })
                    : 0
                  }
                </div>
                <div className="text-sm text-gray-500">Lowest Price (TZS)</div>
              </div>
              
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-600">
                  {regionData.reduce((sum, r) => sum + r.marketCount, 0)}
                </div>
                <div className="text-sm text-gray-500">Total Markets</div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default PriceHeatMap;
