import React, { useState, useEffect } from 'react';
import { fetchData } from '../hooks/useApi';

const PriceAlerts = () => {
  const [alerts, setAlerts] = useState([]);
  const [commodities, setCommodities] = useState([]);
  const [markets, setMarkets] = useState([]);
  const [regions, setRegions] = useState([]);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [userEmail, setUserEmail] = useState(localStorage.getItem('userEmail') || '');
  const [loading, setLoading] = useState(false);

  const [newAlert, setNewAlert] = useState({
    user_email: userEmail,
    commodity: '',
    market: '',
    region: '',
    alert_type: 'price_above',
    threshold_price: '',
    percentage_change: '',
    notification_method: 'email'
  });

  useEffect(() => {
    if (userEmail) {
      localStorage.setItem('userEmail', userEmail);
      loadUserAlerts();
    }
    loadDropdownData();
  }, [userEmail]);

  const loadUserAlerts = async () => {
    if (!userEmail) return;
    
    setLoading(true);
    try {
      const data = await fetchData(`/api/price-alerts/user_alerts/?email=${userEmail}`);
      setAlerts(data);
    } catch (error) {
      console.error('Error loading alerts:', error);
    }
    setLoading(false);
  };

  const loadDropdownData = async () => {
    try {
      const [commoditiesData, marketsData, regionsData] = await Promise.all([
        fetchData('/api/commodities/'),
        fetchData('/api/markets/'),
        fetchData('/api/regions/')
      ]);
      setCommodities(commoditiesData.results || commoditiesData);
      setMarkets(marketsData.results || marketsData);
      setRegions(regionsData.results || regionsData);
    } catch (error) {
      console.error('Error loading dropdown data:', error);
    }
  };

  const handleCreateAlert = async (e) => {
    e.preventDefault();
    
    if (!userEmail) {
      alert('Please enter your email address');
      return;
    }

    setLoading(true);
    try {
      const alertData = { ...newAlert, user_email: userEmail };
      
      // Remove empty fields
      if (!alertData.market) delete alertData.market;
      if (!alertData.region) delete alertData.region;
      if (!alertData.threshold_price) delete alertData.threshold_price;
      if (!alertData.percentage_change) delete alertData.percentage_change;

      const response = await fetch('/api/price-alerts/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(alertData)
      });

      if (response.ok) {
        setShowCreateForm(false);
        setNewAlert({
          user_email: userEmail,
          commodity: '',
          market: '',
          region: '',
          alert_type: 'price_above',
          threshold_price: '',
          percentage_change: '',
          notification_method: 'email'
        });
        loadUserAlerts();
        alert('Alert created successfully!');
      } else {
        const error = await response.json();
        alert('Error creating alert: ' + JSON.stringify(error));
      }
    } catch (error) {
      console.error('Error creating alert:', error);
      alert('Error creating alert');
    }
    setLoading(false);
  };

  const toggleAlert = async (alertId) => {
    try {
      const response = await fetch(`/api/price-alerts/${alertId}/toggle_active/`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        }
      });

      if (response.ok) {
        loadUserAlerts();
      }
    } catch (error) {
      console.error('Error toggling alert:', error);
    }
  };

  const deleteAlert = async (alertId) => {
    if (!confirm('Are you sure you want to delete this alert?')) return;

    try {
      const response = await fetch(`/api/price-alerts/${alertId}/`, {
        method: 'DELETE'
      });

      if (response.ok) {
        loadUserAlerts();
      }
    } catch (error) {
      console.error('Error deleting alert:', error);
    }
  };

  const getAlertTypeDisplay = (alertType) => {
    const types = {
      'price_above': 'Price Above',
      'price_below': 'Price Below', 
      'price_change': 'Price Change',
      'volatility_high': 'High Volatility'
    };
    return types[alertType] || alertType;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Price Alerts</h2>
          <p className="text-gray-600">Get notified when prices meet your criteria</p>
        </div>
        <button
          onClick={() => setShowCreateForm(true)}
          className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors"
        >
          + Create Alert
        </button>
      </div>

      {/* Email Input */}
      {!userEmail && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <h3 className="font-medium text-blue-900 mb-2">Enter Your Email</h3>
          <div className="flex gap-2">
            <input
              type="email"
              placeholder="your.email@example.com"
              value={userEmail}
              onChange={(e) => setUserEmail(e.target.value)}
              className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-green-500"
            />
            <button
              onClick={() => {
                if (userEmail) {
                  localStorage.setItem('userEmail', userEmail);
                  loadUserAlerts();
                }
              }}
              className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700"
            >
              Save
            </button>
          </div>
        </div>
      )}

      {/* Create Alert Form */}
      {showCreateForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md max-h-screen overflow-y-auto">
            <h3 className="text-lg font-semibold mb-4">Create Price Alert</h3>
            
            <form onSubmit={handleCreateAlert} className="space-y-4">
              {/* Commodity */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Commodity *
                </label>
                <select
                  value={newAlert.commodity}
                  onChange={(e) => setNewAlert({...newAlert, commodity: e.target.value})}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-green-500"
                >
                  <option value="">Select Commodity</option>
                  {commodities.map(commodity => (
                    <option key={commodity.id} value={commodity.id}>
                      {commodity.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Market (Optional) */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Market (Optional)
                </label>
                <select
                  value={newAlert.market}
                  onChange={(e) => setNewAlert({...newAlert, market: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-green-500"
                >
                  <option value="">All Markets</option>
                  {markets.map(market => (
                    <option key={market.id} value={market.id}>
                      {market.name} ({market.region_name})
                    </option>
                  ))}
                </select>
              </div>

              {/* Alert Type */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Alert Type *
                </label>
                <select
                  value={newAlert.alert_type}
                  onChange={(e) => setNewAlert({...newAlert, alert_type: e.target.value})}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-green-500"
                >
                  <option value="price_above">Price Above Threshold</option>
                  <option value="price_below">Price Below Threshold</option>
                  <option value="price_change">Significant Price Change</option>
                  <option value="volatility_high">High Volatility Alert</option>
                </select>
              </div>

              {/* Threshold Price */}
              {(newAlert.alert_type === 'price_above' || newAlert.alert_type === 'price_below') && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Threshold Price (TZS) *
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    value={newAlert.threshold_price}
                    onChange={(e) => setNewAlert({...newAlert, threshold_price: e.target.value})}
                    required
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-green-500"
                    placeholder="e.g., 1200.00"
                  />
                </div>
              )}

              {/* Percentage Change */}
              {newAlert.alert_type === 'price_change' && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Percentage Change (%) *
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    value={newAlert.percentage_change}
                    onChange={(e) => setNewAlert({...newAlert, percentage_change: e.target.value})}
                    required
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-green-500"
                    placeholder="e.g., 10.5"
                  />
                </div>
              )}

              {/* Buttons */}
              <div className="flex gap-2 pt-4">
                <button
                  type="button"
                  onClick={() => setShowCreateForm(false)}
                  className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="flex-1 bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 disabled:opacity-50"
                >
                  {loading ? 'Creating...' : 'Create Alert'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Alerts List */}
      {userEmail && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="px-6 py-4 border-b border-gray-200">
            <h3 className="text-lg font-medium text-gray-900">
              Your Alerts ({alerts.length})
            </h3>
          </div>
          
          {loading ? (
            <div className="p-6 text-center">Loading alerts...</div>
          ) : alerts.length === 0 ? (
            <div className="p-6 text-center text-gray-500">
              No alerts created yet. Create your first alert to get started!
            </div>
          ) : (
            <div className="divide-y divide-gray-200">
              {alerts.map(alert => (
                <div key={alert.id} className="p-6 flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-medium text-gray-900">
                        {alert.commodity_name}
                      </span>
                      {alert.market_name && (
                        <span className="text-sm text-gray-500">
                          at {alert.market_name}
                        </span>
                      )}
                      <span className={`px-2 py-1 text-xs rounded-full ${
                        alert.is_active 
                          ? 'bg-green-100 text-green-800' 
                          : 'bg-gray-100 text-gray-800'
                      }`}>
                        {alert.is_active ? 'Active' : 'Inactive'}
                      </span>
                    </div>
                    
                    <div className="text-sm text-gray-600">
                      <span className="font-medium">{getAlertTypeDisplay(alert.alert_type)}</span>
                      {alert.threshold_price && (
                        <span> - {Number(alert.threshold_price).toLocaleString()} TZS</span>
                      )}
                      {alert.percentage_change && (
                        <span> - {alert.percentage_change}% change</span>
                      )}
                    </div>
                    
                    <div className="text-xs text-gray-500 mt-1">
                      Created: {new Date(alert.created_at).toLocaleDateString()}
                      {alert.last_triggered && (
                        <span> • Last triggered: {new Date(alert.last_triggered).toLocaleDateString()}</span>
                      )}
                      {alert.trigger_count > 0 && (
                        <span> • Triggered {alert.trigger_count} times</span>
                      )}
                    </div>
                  </div>
                  
                  <div className="flex gap-2 ml-4">
                    <button
                      onClick={() => toggleAlert(alert.id)}
                      className={`px-3 py-1 text-sm rounded-md ${
                        alert.is_active
                          ? 'bg-yellow-100 text-yellow-800 hover:bg-yellow-200'
                          : 'bg-green-100 text-green-800 hover:bg-green-200'
                      }`}
                    >
                      {alert.is_active ? 'Pause' : 'Activate'}
                    </button>
                    <button
                      onClick={() => deleteAlert(alert.id)}
                      className="px-3 py-1 text-sm bg-red-100 text-red-800 rounded-md hover:bg-red-200"
                    >
                      Delete
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default PriceAlerts;
