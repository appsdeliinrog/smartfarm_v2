import { useState, useEffect } from 'react';
import { LineChart, Line, AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { api } from '../api';
import { formatPrice } from '../utils/format';
import { LoadingSpinner, ErrorMessage } from './common/Loading';
import { convertPriceForChart } from '../utils/priceUtils';
import { generatePricePredictions, generatePredictionSummary } from '../utils/predictions';
import { TrendingUp, TrendingDown, Activity, Brain } from 'lucide-react';

export function PriceChart({ commodityId, marketId, marketRegionId, days = 30, priceUnit = 'kg', chartType = 'line', showPredictions = true }) {
  const [data, setData] = useState([]);
  const [combinedData, setCombinedData] = useState([]);
  const [predictions, setPredictions] = useState(null);
  const [predictionSummary, setPredictionSummary] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchTrendData = async () => {
      if (!commodityId) return;
      
      setLoading(true);
      setError(null);
      try {
        const params = {
          commodity: commodityId,
          days: days,
        };
        
        if (marketId) {
          // If specific market is selected, filter by market
          params.market = marketId;
        } else if (marketRegionId) {
          // If only region is selected, filter by region
          params.market__region = marketRegionId;
        }

        const responseData = await api.getPriceTrends(params);
        
        console.log('Raw trend data received:', responseData);
        
        if (!responseData || responseData.length === 0) {
          setData([]);
          return;
        }
        
        // Group data by date and calculate averages
        const groupedData = responseData.reduce((acc, item) => {
          const date = item.date;
          if (!acc[date]) {
            acc[date] = {
              date,
              prices: [],
              min_prices: [],
              max_prices: []
            };
          }
          
          const minPrice = parseFloat(item.avg_min_price || 0);
          const maxPrice = parseFloat(item.avg_max_price || 0);
          const avgPrice = (minPrice + maxPrice) / 2;
          
          if (!isNaN(minPrice) && !isNaN(maxPrice) && minPrice > 0 && maxPrice > 0) {
            acc[date].prices.push(avgPrice);
            acc[date].min_prices.push(minPrice);
            acc[date].max_prices.push(maxPrice);
          }
          
          return acc;
        }, {});
        
        console.log('Grouped data:', groupedData);
        console.log('Grouped data:', groupedData);
        
        // Convert to chart data with averages and unit conversion
        const chartData = Object.values(groupedData)
          .filter(item => item.prices.length > 0)
          .map(item => {
            const dateObj = new Date(item.date);
            const avgPrice = item.prices.reduce((sum, p) => sum + p, 0) / item.prices.length;
            const minPrice = Math.min(...item.min_prices);
            const maxPrice = Math.max(...item.max_prices);
            
            return {
              date: `${dateObj.getMonth() + 1}/${dateObj.getDate()}`,
              fullDate: item.date,
              sortDate: dateObj,
              price: convertPriceForChart(avgPrice, priceUnit),
              min_price: convertPriceForChart(minPrice, priceUnit),
              max_price: convertPriceForChart(maxPrice, priceUnit),
              avg_price: convertPriceForChart(avgPrice, priceUnit),
            };
          }).sort((a, b) => a.sortDate - b.sortDate);
        
        console.log('Final chart data:', chartData);
        setData(chartData);

        // Generate predictions if enabled and we have sufficient data
        if (showPredictions && chartData.length >= 5) {
          try {
            const predictionData = generatePricePredictions(chartData, 7);
            setPredictions(predictionData);
            
            const summary = generatePredictionSummary(predictionData);
            setPredictionSummary(summary);

            // Combine historical and prediction data for chart
            const predictionChartData = predictionData.predictions.map(pred => {
              const predDate = new Date(pred.date);
              return {
                date: `${predDate.getMonth() + 1}/${predDate.getDate()}`,
                fullDate: pred.date,
                sortDate: predDate,
                predicted_price: convertPriceForChart(pred.predicted_price, priceUnit),
                upper_bound: convertPriceForChart(pred.upper_bound, priceUnit),
                lower_bound: convertPriceForChart(pred.lower_bound, priceUnit),
                confidence: pred.confidence,
                isPrediction: true
              };
            });

            // Combine historical and prediction data
            const combined = [...chartData, ...predictionChartData].sort((a, b) => a.sortDate - b.sortDate);
            setCombinedData(combined);
          } catch (predError) {
            console.error('Error generating predictions:', predError);
            setCombinedData(chartData);
          }
        } else {
          setCombinedData(chartData);
        }
      } catch (err) {
        console.error('Error fetching trend data:', err);
        setError('Failed to load price trends');
      } finally {
        setLoading(false);
      }
    };

    fetchTrendData();
  }, [commodityId, marketId, marketRegionId, days, priceUnit, chartType]);

  const renderChart = () => {
    const chartData = showPredictions ? combinedData : data;
    const commonProps = {
      data: chartData,
      margin: { top: 5, right: 30, left: 20, bottom: 5 }
    };

    const commonElements = (
      <>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis 
          dataKey="date" 
          fontSize={12}
          tick={{ fontSize: 10 }}
          interval={Math.floor(chartData.length / 8) || 0}
        />
        <YAxis 
          fontSize={12}
          tickFormatter={(value) => formatPrice(value, 'TSh')}
        />
        <Tooltip 
          formatter={(value, name, props) => {
            const displayName = name === 'price' ? 'Average Price' : 
                              name === 'min_price' ? 'Min Price' : 
                              name === 'max_price' ? 'Max Price' :
                              name === 'avg_price' ? 'Average Price' :
                              name === 'predicted_price' ? 'Predicted Price' :
                              name === 'upper_bound' ? 'Upper Bound' :
                              name === 'lower_bound' ? 'Lower Bound' : name;
            
            const formattedValue = formatPrice(value, 'TSh');
            
            if (name === 'predicted_price' && props.payload.confidence) {
              return [`${formattedValue} (${props.payload.confidence.toFixed(0)}% confidence)`, displayName];
            }
            
            return [formattedValue, displayName];
          }}
          labelFormatter={(label) => `Date: ${label}`}
          contentStyle={{ 
            backgroundColor: '#f9fafb', 
            border: '1px solid #e5e7eb',
            borderRadius: '8px',
            fontSize: '14px'
          }}
        />
        <Legend />
      </>
    );

    switch (chartType) {
      case 'area':
        return (
          <AreaChart {...commonProps}>
            {commonElements}
            <Area 
              type="monotone" 
              dataKey="price" 
              stroke="#22c55e" 
              fill="#22c55e"
              fillOpacity={0.3}
              strokeWidth={2}
              name="Average Price"
            />
            <Area 
              type="monotone" 
              dataKey="max_price" 
              stroke="#ef4444" 
              fill="#ef4444"
              fillOpacity={0.1}
              strokeWidth={1}
              name="Max Price"
            />
            <Area 
              type="monotone" 
              dataKey="min_price" 
              stroke="#3b82f6" 
              fill="#3b82f6"
              fillOpacity={0.1}
              strokeWidth={1}
              name="Min Price"
            />
          </AreaChart>
        );
      
      case 'bar':
        return (
          <BarChart {...commonProps}>
            {commonElements}
            <Bar dataKey="price" fill="#22c55e" name="Average Price" />
            <Bar dataKey="max_price" fill="#ef4444" name="Max Price" />
            <Bar dataKey="min_price" fill="#3b82f6" name="Min Price" />
          </BarChart>
        );
      
      default: // line
        return (
          <LineChart {...commonProps}>
            {commonElements}
            <Line 
              type="monotone" 
              dataKey="price" 
              stroke="#22c55e" 
              strokeWidth={3}
              dot={{ fill: '#22c55e', strokeWidth: 2, r: 4 }}
              name="Average Price"
              connectNulls={false}
            />
            <Line 
              type="monotone" 
              dataKey="max_price" 
              stroke="#ef4444" 
              strokeWidth={2}
              dot={{ fill: '#ef4444', strokeWidth: 1, r: 3 }}
              strokeDasharray="5 5"
              name="Max Price"
              connectNulls={false}
            />
            <Line 
              type="monotone" 
              dataKey="min_price" 
              stroke="#3b82f6" 
              strokeWidth={2}
              dot={{ fill: '#3b82f6', strokeWidth: 1, r: 3 }}
              strokeDasharray="5 5"
              name="Min Price"
              connectNulls={false}
            />
            {showPredictions && (
              <>
                <Line 
                  type="monotone" 
                  dataKey="predicted_price" 
                  stroke="#8b5cf6" 
                  strokeWidth={3}
                  dot={{ fill: '#8b5cf6', strokeWidth: 2, r: 4 }}
                  strokeDasharray="8 4"
                  name="Predicted Price"
                  connectNulls={false}
                />
                <Line 
                  type="monotone" 
                  dataKey="upper_bound" 
                  stroke="#a78bfa" 
                  strokeWidth={1}
                  dot={false}
                  strokeDasharray="3 3"
                  name="Upper Confidence"
                  connectNulls={false}
                />
                <Line 
                  type="monotone" 
                  dataKey="lower_bound" 
                  stroke="#a78bfa" 
                  strokeWidth={1}
                  dot={false}
                  strokeDasharray="3 3"
                  name="Lower Confidence"
                  connectNulls={false}
                />
              </>
            )}
          </LineChart>
        );
    }
  };

  if (loading) return <LoadingSpinner size="lg" />;
  
  if (error) {
    return (
      <div className="bg-white p-6 rounded-lg shadow">
        <ErrorMessage message={error} />
      </div>
    );
  }

  if (data.length === 0) {
    return (
      <div className="bg-white p-6 rounded-lg shadow">
        <p className="text-gray-600">No trend data available for the selected period</p>
      </div>
    );
  }

  return (
    <div className="w-full">
      {/* Prediction Summary */}
      {showPredictions && predictionSummary && (
        <div className="mb-4 p-4 bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg border border-purple-200">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center space-x-2">
              <Brain className="h-5 w-5 text-purple-600" />
              <h3 className="text-sm font-semibold text-purple-800">Price Forecast</h3>
            </div>
            <div className="flex items-center space-x-4 text-xs">
              <span className="text-purple-600">
                Confidence: {predictions?.confidence.toFixed(0)}%
              </span>
              <span className="text-purple-600">
                Accuracy: {predictions?.accuracy.toFixed(0)}%
              </span>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
            <div className="flex items-center space-x-2">
              {predictions?.trend === 'increasing' ? (
                <TrendingUp className="h-4 w-4 text-green-600" />
              ) : predictions?.trend === 'decreasing' ? (
                <TrendingDown className="h-4 w-4 text-red-600" />
              ) : (
                <Activity className="h-4 w-4 text-gray-600" />
              )}
              <span className="text-gray-700">{predictionSummary.summary}</span>
            </div>
            
            <div className="text-gray-600">
              <span className="font-medium">Next Day:</span> {formatPrice(predictionSummary.next_day_prediction, 'TSh')}
            </div>
            
            <div className="text-gray-600">
              <span className="font-medium">Week Ahead:</span> {formatPrice(predictionSummary.week_ahead_prediction, 'TSh')}
            </div>
          </div>
          
          <div className="mt-2 text-xs text-purple-700">
            {predictionSummary.short_term_outlook} • Confidence Level: {predictionSummary.confidence_level}
          </div>
        </div>
      )}
      
      <div className="h-80">
        <ResponsiveContainer width="100%" height="100%">
          {renderChart()}
        </ResponsiveContainer>
      </div>
      
      {/* Chart Legend and Info */}
      <div className="mt-4 flex flex-wrap items-center justify-between text-sm text-gray-600">
        <div className="flex items-center gap-4 flex-wrap">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-green-500 rounded-full"></div>
            <span>Average Price</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-red-500 rounded-full"></div>
            <span>Max Price</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
            <span>Min Price</span>
          </div>
          {showPredictions && (
            <>
              <div className="flex items-center gap-2">
                <div className="w-3 h-1 bg-purple-500 rounded-full"></div>
                <span>Predicted Price</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-px bg-purple-300 rounded-full"></div>
                <span>Confidence Range</span>
              </div>
            </>
          )}
        </div>
        <div className="text-xs text-gray-500">
          {data.length} data points • Last {days} days • per {priceUnit}
          {showPredictions && predictions && (
            <> • {predictions.predictions.length} predictions</>
          )}
        </div>
      </div>
    </div>
  );
}
