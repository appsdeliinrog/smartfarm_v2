import React, { useState, useEffect } from 'react';
import { fetchData } from '../hooks/useApi';

const VolatilityDashboard = ({ priceUnit }) => {
  const [volatilityData, setVolatilityData] = useState([]);
  const [commodities, setCommodities] = useState([]);
  const [selectedCommodity, setSelectedCommodity] = useState('');
  const [loading, setLoading] = useState(false);
  const [timeRange, setTimeRange] = useState('30'); // days
  const [sortBy, setSortBy] = useState('volatility'); // volatility, price, name

  useEffect(() => {
    loadCommodities();
    loadVolatilityData();
  }, []);

  useEffect(() => {
    loadVolatilityData();
  }, [selectedCommodity, timeRange]);

  const loadCommodities = async () => {
    try {
      const data = await fetchData('/api/commodities/');
      setCommodities(data.results || data);
    } catch (error) {
      console.error('Error loading commodities:', error);
    }
  };

  const loadVolatilityData = async () => {
    setLoading(true);
    try {
      // Calculate date range for filtering
      const endDate = new Date();
      const startDate = new Date(endDate.getTime() - (parseInt(timeRange) * 24 * 60 * 60 * 1000));
      
      let endpoint = `/api/price-observations/?ordering=-observed_date&limit=500&observed_date__gte=${startDate.toISOString().split('T')[0]}`;
      if (selectedCommodity) {
        endpoint += `&commodity=${selectedCommodity}`;
      }
      
      console.log('Loading volatility data with endpoint:', endpoint);
      
      const data = await fetchData(endpoint);
      const observations = data.results || data;
      
      console.log('Volatility observations loaded:', observations.length);
      
      // Debug: Check the structure of observations
      if (observations.length > 0) {
        console.log('Sample observation structure for region check:', {
          region_name: observations[0].region_name,
          market_name: observations[0].market_name,
          commodity_name: observations[0].commodity_name
        });
      }
      
      // Calculate volatility by market-commodity combination
      const marketGroups = {};
      
      observations.forEach(obs => {
        
        const marketKey = `${obs.market_name || obs.market?.name}-${obs.commodity_name || obs.commodity?.name}`;
        if (!marketGroups[marketKey]) {
          // Enhanced region extraction logic - use region_name from serializer
          let regionName = obs.region_name || 'Unknown Region';
          
          marketGroups[marketKey] = {
            market_name: obs.market_name || obs.market?.name || 'Unknown Market',
            commodity_name: obs.commodity_name || obs.commodity?.name || 'Unknown Commodity',
            region: regionName,
            prices: [],
            dates: []
          };
        }
        
        let price = obs.price || obs.min_price || obs.max_price || 0;
        
        // Database stores prices per kg (e.g., 900, 1000, 2300 TZS/kg)
        // Convert based on the selected display unit
        if (priceUnit === '100kg') {
          price = price * 100; // Convert from per kg to per 100kg for display
        }
        // If priceUnit is 'kg', use price as-is since it's already per kg
        
        if (price > 0) {
          marketGroups[marketKey].prices.push(price);
          marketGroups[marketKey].dates.push(new Date(obs.observed_date || obs.date));
        }
      });

      console.log('Market groups:', Object.keys(marketGroups).length);

      // Calculate volatility metrics
      const volatilityArray = Object.values(marketGroups)
        .filter(group => group.prices.length >= 3) // Need at least 3 data points for meaningful volatility
        .map(group => {
          const prices = group.prices;
          const mean = prices.reduce((sum, price) => sum + price, 0) / prices.length;
          
          // Calculate standard deviation
          const variance = prices.reduce((sum, price) => sum + Math.pow(price - mean, 2), 0) / (prices.length - 1);
          const stdDev = Math.sqrt(variance);
          
          // Calculate coefficient of variation (volatility percentage)
          const volatility = mean > 0 ? (stdDev / mean) * 100 : 0;
          
          // Calculate price range and trend
          const minPrice = Math.min(...prices);
          const maxPrice = Math.max(...prices);
          const priceRange = maxPrice - minPrice;
          const rangePercent = mean > 0 ? (priceRange / mean) * 100 : 0;
          
          // Calculate price trend (last vs first price)
          const firstPrice = prices[prices.length - 1]; // Oldest (since ordered by date desc)
          const lastPrice = prices[0]; // Most recent
          const priceChange = lastPrice - firstPrice;
          const priceChangePercent = firstPrice > 0 ? (priceChange / firstPrice) * 100 : 0;

          return {
            market_name: group.market_name,
            commodity_name: group.commodity_name,
            region: group.region,
            volatility: volatility,
            averagePrice: mean,
            minPrice: minPrice,
            maxPrice: maxPrice,
            priceRange: priceRange,
            rangePercent: rangePercent,
            priceChange: priceChange,
            priceChangePercent: priceChangePercent,
            dataPoints: prices.length,
            riskLevel: getRiskLevel(volatility),
            trend: priceChangePercent > 2 ? 'increasing' : priceChangePercent < -2 ? 'decreasing' : 'stable'
          };
        });

      // Sort data based on selected sort option
      switch (sortBy) {
        case 'volatility':
          volatilityArray.sort((a, b) => b.volatility - a.volatility);
          break;
        case 'price':
          volatilityArray.sort((a, b) => b.averagePrice - a.averagePrice);
          break;
        case 'name':
          volatilityArray.sort((a, b) => a.market_name.localeCompare(b.market_name));
          break;
        case 'change':
          volatilityArray.sort((a, b) => Math.abs(b.priceChangePercent) - Math.abs(a.priceChangePercent));
          break;
        default:
          volatilityArray.sort((a, b) => b.volatility - a.volatility);
      }
      
      console.log('Processed volatility data:', volatilityArray.length, 'markets');
      setVolatilityData(volatilityArray);
    } catch (error) {
      console.error('Error loading volatility data:', error);
      setVolatilityData([]);
    }
    setLoading(false);
  };

  const getRiskLevel = (volatility) => {
    if (volatility >= 30) return { level: 'Very High', color: 'red', bgColor: 'bg-red-100', textColor: 'text-red-800' };
    if (volatility >= 20) return { level: 'High', color: 'orange', bgColor: 'bg-orange-100', textColor: 'text-orange-800' };
    if (volatility >= 10) return { level: 'Medium', color: 'yellow', bgColor: 'bg-yellow-100', textColor: 'text-yellow-800' };
    if (volatility >= 5) return { level: 'Low', color: 'green', bgColor: 'bg-green-100', textColor: 'text-green-800' };
    return { level: 'Very Low', color: 'blue', bgColor: 'bg-blue-100', textColor: 'text-blue-800' };
  };

  const getVolatilityIcon = (riskLevel) => {
    switch (riskLevel.level) {
      case 'Very High':
        return '⚠️';
      case 'High':
        return '🔺';
      case 'Medium':
        return '📊';
      case 'Low':
        return '📈';
      default:
        return '✅';
    }
  };

  const getTrendIcon = (trend) => {
    switch (trend) {
      case 'increasing':
        return '📈';
      case 'decreasing':
        return '📉';
      default:
        return '➡️';
    }
  };

  const getChangeIcon = (changePercent) => {
    if (changePercent > 5) return '🔴'; // Significant increase
    if (changePercent > 2) return '🟠'; // Moderate increase
    if (changePercent < -5) return '🟢'; // Significant decrease (good for buyers)
    if (changePercent < -2) return '🟡'; // Moderate decrease
    return '⚪'; // Stable
  };

  const selectedCommodityName = commodities.find(c => c.id === parseInt(selectedCommodity))?.name || 'All Commodities';

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Market Volatility Dashboard</h2>
          <p className="text-gray-600">Monitor price stability and trading risks across markets</p>
        </div>
        
        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-2">
          <select
            value={selectedCommodity}
            onChange={(e) => setSelectedCommodity(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
          >
            <option value="">All Commodities</option>
            {commodities.map(commodity => (
              <option key={commodity.id} value={commodity.id}>
                {commodity.name}
              </option>
            ))}
          </select>
          
          <select
            value={timeRange}
            onChange={(e) => setTimeRange(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
          >
            <option value="7">Last 7 days</option>
            <option value="14">Last 2 weeks</option>
            <option value="30">Last 30 days</option>
            <option value="60">Last 2 months</option>
            <option value="90">Last 3 months</option>
          </select>
          
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
          >
            <option value="volatility">Sort by Volatility</option>
            <option value="price">Sort by Price</option>
            <option value="change">Sort by Price Change</option>
            <option value="name">Sort by Market Name</option>
          </select>
        </div>
      </div>

      {/* Risk Level Legend */}
      <div className="bg-white rounded-lg border p-4">
        <h3 className="font-medium text-gray-900 mb-3">Volatility Risk Levels</h3>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
          <div className="flex items-center gap-2">
            <span>⚠️</span>
            <span className="text-sm">Very High (30%+)</span>
          </div>
          <div className="flex items-center gap-2">
            <span>🔺</span>
            <span className="text-sm">High (20-30%)</span>
          </div>
          <div className="flex items-center gap-2">
            <span>📊</span>
            <span className="text-sm">Medium (10-20%)</span>
          </div>
          <div className="flex items-center gap-2">
            <span>📈</span>
            <span className="text-sm">Low (5-10%)</span>
          </div>
          <div className="flex items-center gap-2">
            <span>✅</span>
            <span className="text-sm">Very Low (0-5%)</span>
          </div>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <div className="bg-white rounded-lg border p-4">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-red-500">⚠️</span>
            <span className="text-sm font-medium text-gray-700">High Risk</span>
          </div>
          <div className="text-2xl font-bold text-red-600">
            {volatilityData.filter(item => item.volatility >= 20).length}
          </div>
          <div className="text-xs text-gray-500">Markets (20%+ volatility)</div>
        </div>

        <div className="bg-white rounded-lg border p-4">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-green-500">✅</span>
            <span className="text-sm font-medium text-gray-700">Stable</span>
          </div>
          <div className="text-2xl font-bold text-green-600">
            {volatilityData.filter(item => item.volatility < 10).length}
          </div>
          <div className="text-xs text-gray-500">Markets (&lt;10% volatility)</div>
        </div>

        <div className="bg-white rounded-lg border p-4">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-blue-500">📊</span>
            <span className="text-sm font-medium text-gray-700">Avg Volatility</span>
          </div>
          <div className="text-2xl font-bold text-blue-600">
            {volatilityData.length > 0 
              ? (volatilityData.reduce((sum, item) => sum + item.volatility, 0) / volatilityData.length).toFixed(1)
              : 0
            }%
          </div>
          <div className="text-xs text-gray-500">Across all markets</div>
        </div>

        <div className="bg-white rounded-lg border p-4">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-orange-500">📈</span>
            <span className="text-sm font-medium text-gray-700">Rising Prices</span>
          </div>
          <div className="text-2xl font-bold text-orange-600">
            {volatilityData.filter(item => item.trend === 'increasing').length}
          </div>
          <div className="text-xs text-gray-500">Markets with upward trend</div>
        </div>

        <div className="bg-white rounded-lg border p-4">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-purple-500">🏪</span>
            <span className="text-sm font-medium text-gray-700">Total Markets</span>
          </div>
          <div className="text-2xl font-bold text-purple-600">
            {volatilityData.length}
          </div>
          <div className="text-xs text-gray-500">Analyzed in {timeRange} days</div>
        </div>
      </div>

      {/* Volatility Table */}
      <div className="bg-white rounded-lg border">
        <div className="p-6 border-b">
          <h3 className="text-lg font-medium text-gray-900">
            Volatility Analysis - {selectedCommodityName}
          </h3>
          {loading && <p className="text-sm text-gray-500 mt-1">Loading volatility data...</p>}
        </div>

        {loading ? (
          <div className="p-8 text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600 mx-auto"></div>
            <p className="mt-2 text-gray-500">Calculating market volatility...</p>
          </div>
        ) : volatilityData.length === 0 ? (
          <div className="p-8 text-center text-gray-500">
            No volatility data available. Need more price observations to calculate volatility.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Market
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Commodity
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Volatility
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Risk Level
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Avg Price
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Price Range
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Price Change
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Data Points
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {volatilityData.slice(0, 50).map((item, index) => (
                  <tr key={`${item.market_name}-${item.commodity_name}`} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div>
                        <div className="text-sm font-medium text-gray-900">{item.market_name}</div>
                        <div className="text-sm text-gray-500">{item.region}</div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {item.commodity_name}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center gap-2">
                        <span className="text-lg">{getVolatilityIcon(item.riskLevel)}</span>
                        <span className="text-sm font-medium text-gray-900">
                          {item.volatility.toFixed(1)}%
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${item.riskLevel.bgColor} ${item.riskLevel.textColor}`}>
                        {item.riskLevel.level}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {item.averagePrice.toLocaleString(undefined, { maximumFractionDigits: 0 })} TZS
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">
                        {item.minPrice.toLocaleString(undefined, { maximumFractionDigits: 0 })} - {item.maxPrice.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                      </div>
                      <div className="text-xs text-gray-500">
                        ±{item.rangePercent.toFixed(1)}%
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className={`flex items-center gap-1 text-sm font-medium ${
                        item.priceChangePercent > 2 ? 'text-red-600' : 
                        item.priceChangePercent < -2 ? 'text-green-600' : 'text-gray-600'
                      }`}>
                        <span>
                          {item.priceChangePercent > 2 ? '↗️' : 
                           item.priceChangePercent < -2 ? '↘️' : '→'}
                        </span>
                        <span>{item.priceChangePercent > 0 ? '+' : ''}{item.priceChangePercent.toFixed(1)}%</span>
                      </div>
                      <div className="text-xs text-gray-500">
                        {Math.abs(item.priceChange).toLocaleString(undefined, { maximumFractionDigits: 0 })} TZS
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {item.dataPoints} observations
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            
            {/* Table Footer */}
            {volatilityData.length > 50 && (
              <div className="px-6 py-3 bg-gray-50 border-t text-sm text-gray-500 text-center">
                Showing first 50 of {volatilityData.length} markets. Use filters to narrow down results.
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default VolatilityDashboard;
