import { useState, useEffect } from 'react';
import { api } from '../api';
import { convertPrice, getUnitDisplayText } from '../utils/priceUtils';

export function BestPriceFinder({ priceUnit = 'kg' }) {
  const [commodities, setCommodities] = useState([]);
  const [selectedCommodity, setSelectedCommodity] = useState('');
  const [bestPrices, setBestPrices] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [selectedDays, setSelectedDays] = useState(7); // Default to 7 days
  const [showDateDropdown, setShowDateDropdown] = useState(false);
  const [customStartDate, setCustomStartDate] = useState('');
  const [customEndDate, setCustomEndDate] = useState('');
  const [isCustomRange, setIsCustomRange] = useState(false);

  // Load commodities on component mount
  useEffect(() => {
    const loadCommodities = async () => {
      try {
        const response = await api.getCommodities();
        const commodityList = response.results || response;
        setCommodities(commodityList);
      } catch (err) {
        console.error('Error loading commodities:', err);
        setError('Failed to load commodities. Please check if the backend server is running.');
      }
    };
    loadCommodities();
  }, []);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (showDateDropdown && !event.target.closest('.date-dropdown')) {
        setShowDateDropdown(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [showDateDropdown]);

  const handleCommodityChange = async (commodityId) => {
    setSelectedCommodity(commodityId);
    if (!commodityId) {
      setBestPrices(null);
      return;
    }

    setLoading(true);
    setError('');
    
    try {
      const response = await api.getBestPrices({ 
        commodity: commodityId,
        days: selectedDays 
      });
      setBestPrices(response);
    } catch (err) {
      setError('Failed to load price data. Please try again.');
      console.error('Error loading best prices:', err);
    } finally {
      setLoading(false);
    }
  };

  const formatPrice = (price) => {
    return new Intl.NumberFormat('en-TZ', {
      style: 'currency',
      currency: 'TZS',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(convertPrice(price, priceUnit));
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const handleDateRangeChange = async (days) => {
    if (days === 'custom') {
      setIsCustomRange(true);
      setShowDateDropdown(false);
      return;
    }
    
    setIsCustomRange(false);
    setSelectedDays(days);
    setShowDateDropdown(false);
    
    if (selectedCommodity) {
      setLoading(true);
      setError('');
      
      try {
        const response = await api.getBestPrices({ 
          commodity: selectedCommodity,
          days: days 
        });
        setBestPrices(response);
      } catch (err) {
        setError('Failed to load price data. Please try again.');
        console.error('Error loading best prices:', err);
      } finally {
        setLoading(false);
      }
    }
  };

  const handleCustomDateApply = async () => {
    if (!customStartDate || !customEndDate) {
      setError('Please select both start and end dates.');
      return;
    }

    const startDate = new Date(customStartDate);
    const endDate = new Date(customEndDate);
    const daysDiff = Math.ceil((endDate - startDate) / (1000 * 60 * 60 * 24));

    if (daysDiff < 1) {
      setError('End date must be after start date.');
      return;
    }

    if (daysDiff > 365) {
      setError('Date range cannot exceed 365 days.');
      return;
    }

    setIsCustomRange(false);
    setSelectedDays(daysDiff);
    
    if (selectedCommodity) {
      setLoading(true);
      setError('');
      
      try {
        const response = await api.getBestPrices({ 
          commodity: selectedCommodity,
          days: daysDiff 
        });
        setBestPrices(response);
      } catch (err) {
        setError('Failed to load price data. Please try again.');
        console.error('Error loading best prices:', err);
      } finally {
        setLoading(false);
      }
    }
  };

  const handleCustomDateCancel = () => {
    setIsCustomRange(false);
    setCustomStartDate('');
    setCustomEndDate('');
  };

  const getDateRangeText = () => {
    if (isCustomRange) {
      return 'Custom Range';
    }
    
    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(endDate.getDate() - selectedDays + 1);
    
    return `${startDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} - ${endDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}`;
  };

  const PriceCard = ({ title, data, type, icon, color }) => (
    <div className={`bg-white rounded-lg shadow-md p-6 border-l-4 ${color}`}>
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-900 flex items-center">
          <span className="text-2xl mr-2">{icon}</span>
          {title}
        </h3>
      </div>
      
      {data && data.length > 0 ? (
        <div className="space-y-3">
          {data.slice(0, 5).map((item, index) => (
            <div key={index} className={`p-3 rounded-lg ${index === 0 ? 'bg-green-50 border border-green-200' : 'bg-gray-50'}`}>
              <div className="flex justify-between items-center">
                <div>
                  <p className="font-medium text-gray-900">{item.market__name}</p>
                  <p className="text-sm text-gray-600">{item.market__region__name}</p>
                  <p className="text-xs text-blue-600 mt-1">
                    📅 {formatDate(item.observed_date)}
                  </p>
                </div>
                <div className="text-right">
                  <p className={`font-bold ${index === 0 ? 'text-green-700 text-lg' : 'text-gray-900'}`}>
                    {formatPrice(item.price)} {getUnitDisplayText(priceUnit)}
                  </p>
                  {index > 0 && (
                    <p className="text-xs text-gray-500">
                      +{formatPrice(item[type === 'buying' ? 'difference_from_cheapest' : 'difference_from_highest'])} 
                      ({item.percentage_difference.toFixed(1)}%)
                    </p>
                  )}
                  {index === 0 && (
                    <p className="text-xs text-green-600 font-medium">
                      {type === 'buying' ? 'BEST BUY' : 'BEST SELL'} ⭐
                    </p>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <p className="text-gray-500 text-center py-4">No data available</p>
      )}
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-lg shadow-sm p-6">
        <div className="flex justify-between items-start mb-4">
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">🎯 Best Price Finder</h2>
            <p className="text-gray-600">
              Find the best markets to buy (lowest prices) and sell (highest prices) your commodities
            </p>
          </div>
          {bestPrices && (
            <div className="text-right">
              <div className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                🟢 Live Data
              </div>
              <div className="relative mt-2">
                <button
                  onClick={() => setShowDateDropdown(!showDateDropdown)}
                  className="date-dropdown inline-flex items-center px-3 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
                >
                  📅 {selectedDays} days ({getDateRangeText()})
                  <svg className="ml-2 h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </button>
                
                {showDateDropdown && (
                  <div className="date-dropdown absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg z-10 border border-gray-200">
                    <div className="py-1">
                      {[7, 14, 30].map((days) => (
                        <button
                          key={days}
                          onClick={() => handleDateRangeChange(days)}
                          className={`block w-full text-left px-4 py-2 text-sm hover:bg-gray-100 ${
                            selectedDays === days && !isCustomRange ? 'bg-green-50 text-green-700 font-medium' : 'text-gray-700'
                          }`}
                        >
                          {days} days ({(() => {
                            const endDate = new Date();
                            const startDate = new Date();
                            startDate.setDate(endDate.getDate() - days + 1);
                            return `${startDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} - ${endDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}`;
                          })()})
                        </button>
                      ))}
                      <div className="border-t border-gray-200 my-1"></div>
                      <button
                        onClick={() => handleDateRangeChange('custom')}
                        className={`block w-full text-left px-4 py-2 text-sm hover:bg-gray-100 ${
                          isCustomRange ? 'bg-green-50 text-green-700 font-medium' : 'text-gray-700'
                        }`}
                      >
                        📅 Custom Range
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
        
        {/* Commodity Selector */}
        <div className="max-w-md">
          <label htmlFor="commodity-select" className="block text-sm font-medium text-gray-700 mb-2">
            Select Commodity:
          </label>
          <select
            id="commodity-select"
            value={selectedCommodity}
            onChange={(e) => handleCommodityChange(e.target.value)}
            className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
          >
            <option value="">Choose a commodity...</option>
            {commodities.map((commodity) => (
              <option key={commodity.id} value={commodity.id}>
                {commodity.name}
              </option>
            ))}
          </select>
        </div>
        
        {/* Custom Date Range Modal */}
        {isCustomRange && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-lg shadow-xl max-w-md w-full p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Select Custom Date Range</h3>
              
              <div className="space-y-4">
                <div>
                  <label htmlFor="start-date" className="block text-sm font-medium text-gray-700 mb-1">
                    Start Date
                  </label>
                  <input
                    type="date"
                    id="start-date"
                    value={customStartDate}
                    onChange={(e) => setCustomStartDate(e.target.value)}
                    max={new Date().toISOString().split('T')[0]}
                    className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
                  />
                </div>
                
                <div>
                  <label htmlFor="end-date" className="block text-sm font-medium text-gray-700 mb-1">
                    End Date
                  </label>
                  <input
                    type="date"
                    id="end-date"
                    value={customEndDate}
                    onChange={(e) => setCustomEndDate(e.target.value)}
                    max={new Date().toISOString().split('T')[0]}
                    min={customStartDate}
                    className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
                  />
                </div>
                
                {customStartDate && customEndDate && (
                  <div className="text-sm text-gray-600 bg-gray-50 p-3 rounded-md">
                    📅 Selected range: {new Date(customStartDate).toLocaleDateString('en-US', { 
                      month: 'short', day: 'numeric', year: 'numeric' 
                    })} - {new Date(customEndDate).toLocaleDateString('en-US', { 
                      month: 'short', day: 'numeric', year: 'numeric' 
                    })} ({Math.ceil((new Date(customEndDate) - new Date(customStartDate)) / (1000 * 60 * 60 * 24))} days)
                  </div>
                )}
              </div>
              
              <div className="flex justify-end space-x-3 mt-6">
                <button
                  onClick={handleCustomDateCancel}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 border border-gray-300 rounded-md hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500"
                >
                  Cancel
                </button>
                <button
                  onClick={handleCustomDateApply}
                  disabled={!customStartDate || !customEndDate}
                  className="px-4 py-2 text-sm font-medium text-white bg-green-600 border border-transparent rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Apply Range
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Loading State */}
      {loading && (
        <div className="text-center py-8">
          <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-green-500"></div>
          <p className="mt-2 text-gray-600">Finding best prices...</p>
        </div>
      )}

      {/* Error State */}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <p className="text-red-700">{error}</p>
        </div>
      )}

      {/* Results */}
      {bestPrices && !loading && (
        <>
          {/* Arbitrage Opportunity Alert */}
          {bestPrices.arbitrage_opportunity && bestPrices.arbitrage_opportunity.max_profit_per_kg > 0 && (
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
              <h3 className="text-lg font-semibold text-yellow-800 mb-2">🔥 Arbitrage Opportunity!</h3>
              <p className="text-yellow-700">
                <strong>Potential Profit:</strong> {formatPrice(bestPrices.arbitrage_opportunity.max_profit_per_kg)} per {priceUnit}
              </p>
              <p className="text-sm text-yellow-600 mt-1">
                Buy from <strong>{bestPrices.arbitrage_opportunity.best_buy_market}</strong> → 
                Sell to <strong>{bestPrices.arbitrage_opportunity.best_sell_market}</strong>
              </p>
              <p className="text-xs text-yellow-600 mt-2">
                📅 Based on data from {formatDate(bestPrices.date_range.start)} to {formatDate(bestPrices.date_range.end)}
              </p>
            </div>
          )}

          {/* Price Cards */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <PriceCard
              title="Best Markets to BUY (Lowest Prices)"
              data={bestPrices.best_for_buying}
              type="buying"
              icon="💰"
              color="border-green-500"
            />
            
            <PriceCard
              title="Best Markets to SELL (Highest Prices)"
              data={bestPrices.best_for_selling}
              type="selling"
              icon="📈"
              color="border-blue-500"
            />
          </div>

          {/* Summary Info */}
          <div className="bg-gray-50 rounded-lg p-4">
            <div className="flex flex-wrap items-center justify-between">
              <div className="flex items-center space-x-4 text-sm text-gray-600">
                <span>📅 Data from {getDateRangeText()}</span>
                <span>🔄 Prices per {priceUnit}</span>
                <span>💡 Transport costs not included</span>
              </div>
              <div className="text-xs text-gray-500 mt-2 lg:mt-0">
                Last updated: {bestPrices ? formatDate(bestPrices.date_range.end) : 'N/A'}
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
