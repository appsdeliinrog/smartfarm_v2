import { useState } from 'react';
import { useLatestPrices } from '../hooks/useApi';
import { LoadingSpinner, ErrorMessage } from './common/Loading';
import { PriceHistoryModal } from './PriceHistoryModal';
import { formatPrice, formatDate } from '../utils/format';
import { convertPrice } from '../utils/priceUtils';
import { BarChart3 } from 'lucide-react';

export function PriceGrid({ filters, priceUnit = 'kg' }) {
  const { data, loading, error, refetch } = useLatestPrices(filters);
  const [selectedPrice, setSelectedPrice] = useState(null);
  const [showHistoryModal, setShowHistoryModal] = useState(false);

  const handlePriceCardClick = (entry, commodityId, marketId) => {
    setSelectedPrice({
      commodityId,
      commodityName: entry.commodity,
      marketId,
      marketName: entry.market,
      regionName: entry.region,
      currentPrice: {
        min: entry.prices.min,
        max: entry.prices.max,
        avg: entry.prices.min && entry.prices.max ? 
          (parseFloat(entry.prices.min) + parseFloat(entry.prices.max)) / 2 : 
          null,
        date: entry.date
      }
    });
    setShowHistoryModal(true);
  };

  if (loading) return <LoadingSpinner size="lg" />;
  if (error) return <ErrorMessage message={error} onRetry={refetch} />;

  const prices = data || [];
  
  // Group prices by commodity and market for better display
  const groupedPrices = prices.reduce((acc, price) => {
    const key = `${price.commodity_name}-${price.market_name}`;
    if (!acc[key]) {
      acc[key] = {
        commodity: price.commodity_name,
        commodityId: price.commodity,
        market: price.market_name,
        marketId: price.market,
        region: price.region_name,
        date: price.observed_date,
        prices: {}
      };
    }
    acc[key].prices[price.stat] = price.price;
    return acc;
  }, {});

  const priceEntries = Object.values(groupedPrices);

  if (priceEntries.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500">No price data available for the selected filters.</p>
      </div>
    );
  }

  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {priceEntries.map((entry, index) => (
          <div 
            key={index} 
            className="price-card group cursor-pointer hover:shadow-lg hover:border-green-300 transition-all duration-200 transform hover:scale-105"
            onClick={() => handlePriceCardClick(entry, entry.commodityId, entry.marketId)}
          >
            <div className="flex justify-between items-start mb-3">
              <div>
                <h3 className="font-semibold text-gray-900">{entry.commodity}</h3>
                <p className="text-sm text-gray-600">{entry.market}, {entry.region}</p>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs text-gray-500">
                  {formatDate(entry.date)}
                </span>
                <BarChart3 className="h-4 w-4 text-gray-400 hover:text-green-600 transition-colors" />
              </div>
            </div>
            
            <div className="space-y-2">
              {entry.prices.min && (
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Min Price:</span>
                  <span className="font-medium text-green-600">
                    {formatPrice(convertPrice(entry.prices.min, priceUnit))} TZS/{priceUnit}
                  </span>
                </div>
              )}
              {entry.prices.max && (
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Max Price:</span>
                  <span className="font-medium text-red-600">
                    {formatPrice(convertPrice(entry.prices.max, priceUnit))} TZS/{priceUnit}
                  </span>
                </div>
              )}
              {entry.prices.min && entry.prices.max && (
                <div className="flex justify-between pt-2 border-t">
                  <span className="text-sm text-gray-600">Avg Price:</span>
                  <span className="font-medium text-blue-600">
                    {formatPrice(convertPrice((parseFloat(entry.prices.min) + parseFloat(entry.prices.max)) / 2, priceUnit))} TZS/{priceUnit}
                  </span>
                </div>
              )}
            </div>
            
            {/* Click indicator */}
            <div className="mt-3 text-xs text-gray-400 text-center opacity-0 group-hover:opacity-100 transition-opacity">
              Click to view price history
            </div>
          </div>
        ))}
      </div>

      {/* Price History Modal */}
      {selectedPrice && (
        <PriceHistoryModal
          isOpen={showHistoryModal}
          onClose={() => {
            setShowHistoryModal(false);
            setSelectedPrice(null);
          }}
          commodityId={selectedPrice.commodityId}
          commodityName={selectedPrice.commodityName}
          marketId={selectedPrice.marketId}
          marketName={selectedPrice.marketName}
          regionName={selectedPrice.regionName}
          priceUnit={priceUnit}
          currentPrice={selectedPrice.currentPrice}
        />
      )}
    </>
  );
}
