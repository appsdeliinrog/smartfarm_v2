import { useState, useEffect } from 'react';
import { api } from '../api';

export function LicenseAdmin() {
  const [licenseStatus, setLicenseStatus] = useState(null);
  const [demoKey, setDemoKey] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    checkLicenseStatus();
  }, []);

  const checkLicenseStatus = async () => {
    try {
      const response = await api.get('/license/status/');
      setLicenseStatus(response);
    } catch (error) {
      console.error('License check failed:', error);
    }
  };

  const generateDemoKey = async () => {
    setLoading(true);
    try {
      const response = await api.get('/license/demo-key/?client=Demo%20Client');
      setDemoKey(response.demo_key);
    } catch (error) {
      console.error('Demo key generation failed:', error);
    } finally {
      setLoading(false);
    }
  };

  const deactivateLicense = async () => {
    if (confirm('Are you sure you want to deactivate the current license?')) {
      try {
        await api.delete('/license/deactivate/');
        await checkLicenseStatus();
        window.location.reload();
      } catch (error) {
        console.error('Deactivation failed:', error);
      }
    }
  };

  return (
    <div className="max-w-2xl mx-auto p-6 bg-white rounded-lg shadow-lg">
      <h2 className="text-2xl font-bold mb-6 text-gray-900">License Management</h2>
      
      {/* Current License Status */}
      <div className="mb-6 p-4 rounded-lg border">
        <h3 className="text-lg font-semibold mb-3">Current Status</h3>
        {licenseStatus ? (
          <div className={`p-4 rounded ${
            licenseStatus.licensed 
              ? 'bg-green-100 text-green-800' 
              : 'bg-red-100 text-red-800'
          }`}>
            <div className="flex items-center justify-between">
              <div>
                <p className="font-semibold">
                  {licenseStatus.licensed ? '✅ Licensed' : '❌ Unlicensed'}
                </p>
                <p className="text-sm">{licenseStatus.message}</p>
                {licenseStatus.client && (
                  <p className="text-sm mt-1">Client: {licenseStatus.client}</p>
                )}
                {licenseStatus.expires && (
                  <p className="text-sm">Expires: {licenseStatus.expires.split('T')[0]}</p>
                )}
              </div>
              {licenseStatus.licensed && (
                <button
                  onClick={deactivateLicense}
                  className="px-3 py-1 bg-red-600 text-white rounded text-sm hover:bg-red-700"
                >
                  Deactivate
                </button>
              )}
            </div>
          </div>
        ) : (
          <div className="animate-pulse bg-gray-200 h-16 rounded"></div>
        )}
      </div>

      {/* Demo Key Generator */}
      <div className="mb-6 p-4 rounded-lg border bg-blue-50">
        <h3 className="text-lg font-semibold mb-3 text-blue-900">Demo License Key</h3>
        <p className="text-sm text-blue-700 mb-3">
          Generate a 30-day demo license key for testing purposes.
        </p>
        <button
          onClick={generateDemoKey}
          disabled={loading}
          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50"
        >
          {loading ? 'Generating...' : 'Generate Demo Key'}
        </button>
        
        {demoKey && (
          <div className="mt-4 p-3 bg-white rounded border">
            <p className="text-sm font-medium text-gray-700 mb-1">Demo License Key:</p>
            <p className="font-mono text-lg text-blue-600 break-all">{demoKey}</p>
            <p className="text-xs text-gray-500 mt-2">
              Use client name: "Demo Client" to activate this key
            </p>
          </div>
        )}
      </div>

      {/* Instructions */}
      <div className="p-4 rounded-lg border bg-gray-50">
        <h3 className="text-lg font-semibold mb-3">Instructions</h3>
        <div className="text-sm text-gray-700 space-y-2">
          <p><strong>For Clients:</strong></p>
          <ul className="list-disc list-inside pl-4 space-y-1">
            <li>Contact the developer to purchase a license key</li>
            <li>Use the "Activate License" button in the red banner</li>
            <li>Enter your organization name and license key</li>
            <li>The watermark will disappear once activated</li>
          </ul>
          
          <p className="mt-4"><strong>For Developers:</strong></p>
          <ul className="list-disc list-inside pl-4 space-y-1">
            <li>Use the license key generator script to create keys</li>
            <li>Provide the key and setup instructions to clients</li>
            <li>Keys are validated against client organization names</li>
            <li>Default license validity is 365 days</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
