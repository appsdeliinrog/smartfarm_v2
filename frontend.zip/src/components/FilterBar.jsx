import { useState, useEffect } from 'react';
import { useCommodities, useRegions } from '../hooks/useApi';
import { api } from '../api';

export function FilterBar({ onFilterChange, filters }) {
  const { data: commodities } = useCommodities();
  const { data: regions } = useRegions();
  const [markets, setMarkets] = useState([]);
  const [allMarkets, setAllMarkets] = useState([]);

  // Load all markets on component mount
  useEffect(() => {
    const loadMarkets = async () => {
      try {
        const marketsRes = await api.getMarkets();
        const marketsData = marketsRes.results || marketsRes;
        setAllMarkets(marketsData);
        setMarkets(marketsData);
      } catch (error) {
        console.error('Error loading markets:', error);
      }
    };
    loadMarkets();
  }, []);

  // Filter markets when region selection changes
  useEffect(() => {
    if (filters.market__region) {
      const filteredMarkets = allMarkets.filter(market => 
        market.region === parseInt(filters.market__region)
      );
      setMarkets(filteredMarkets);
      
      // Clear market selection if current market is not in the filtered list
      if (filters.market && !filteredMarkets.some(m => m.id === parseInt(filters.market))) {
        handleFilterChange('market', '');
      }
    } else {
      setMarkets(allMarkets);
      // Clear market selection when no region is selected
      if (filters.market) {
        handleFilterChange('market', '');
      }
    }
  }, [filters.market__region, allMarkets]);

  const handleFilterChange = (key, value) => {
    const newFilters = { ...filters, [key]: value };
    if (value === '') {
      delete newFilters[key];
    }
    onFilterChange(newFilters);
  };

  return (
    <div className="bg-white p-4 rounded-lg shadow-sm border mb-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Commodity
          </label>
          <select
            value={filters.commodity || ''}
            onChange={(e) => handleFilterChange('commodity', e.target.value)}
            className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500"
          >
            <option value="">All Commodities</option>
            {commodities?.results?.map((commodity) => (
              <option key={commodity.id} value={commodity.id}>
                {commodity.name}{commodity.swahili_name ? ` (${commodity.swahili_name})` : ''}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Region
          </label>
          <select
            value={filters.market__region || ''}
            onChange={(e) => handleFilterChange('market__region', e.target.value)}
            className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500"
          >
            <option value="">All Regions</option>
            {regions?.results?.map((region) => (
              <option key={region.id} value={region.id}>
                {region.name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Market
          </label>
          <select
            value={filters.market || ''}
            onChange={(e) => handleFilterChange('market', e.target.value)}
            className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 disabled:bg-gray-50 disabled:text-gray-500"
            disabled={!filters.market__region}
          >
            <option value="">
              {filters.market__region ? 'All Markets in Region' : 'All Markets'}
            </option>
            {markets.map((market) => (
              <option key={market.id} value={market.id}>
                {market.name}
              </option>
            ))}
          </select>
          {!filters.market__region && (
            <p className="text-xs text-gray-500 mt-1">
              Select a region first to filter by specific markets
            </p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Date Range (Days)
          </label>
          <select
            value={filters.days || '30'}
            onChange={(e) => handleFilterChange('days', e.target.value)}
            className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500"
          >
            <option value="7">Last 7 days</option>
            <option value="30">Last 30 days</option>
            <option value="90">Last 90 days</option>
          </select>
        </div>
      </div>

      {/* Active Filters Display */}
      {(filters.commodity || filters.market__region || filters.market || filters.days !== '30') && (
        <div className="mt-4 pt-4 border-t border-gray-200">
          <div className="flex items-center gap-2 text-sm">
            <span className="text-gray-600 font-medium">Active Filters:</span>
            <div className="flex flex-wrap gap-2">
              {filters.commodity && (
                <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                  📊 {commodities?.results?.find(c => c.id === parseInt(filters.commodity))?.name || 'Selected Commodity'}
                </span>
              )}
              {filters.market__region && (
                <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                  🌍 {regions?.results?.find(r => r.id === parseInt(filters.market__region))?.name || 'Selected Region'}
                </span>
              )}
              {filters.market && (
                <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">
                  🏪 {markets.find(m => m.id === parseInt(filters.market))?.name || 'Selected Market'}
                </span>
              )}
              {filters.days && filters.days !== '30' && (
                <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
                  📅 {filters.days} days
                </span>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
