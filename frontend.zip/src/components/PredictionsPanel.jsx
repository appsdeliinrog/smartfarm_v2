import { useState, useEffect } from 'react';
import { api } from '../api';
import { generatePricePredictions, generatePredictionSummary, analyzeSeasonalPatterns } from '../utils/predictions';
import { formatPrice } from '../utils/format';
import { convertPrice } from '../utils/priceUtils';
import { TrendingUp, TrendingDown, Activity, Brain, Calendar, AlertCircle, Target } from 'lucide-react';
import { LoadingSpinner } from './common/Loading';

export function PredictionsPanel({ commodityId, marketId, priceUnit = 'kg' }) {
  const [predictions, setPredictions] = useState(null);
  const [predictionSummary, setPredictionSummary] = useState(null);
  const [seasonalAnalysis, setSeasonalAnalysis] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchPredictions = async () => {
      if (!commodityId) return;
      
      setLoading(true);
      setError(null);
      
      try {
        // Fetch historical data for predictions
        const params = {
          commodity: commodityId,
          days: 60, // More data for better predictions
        };
        
        if (marketId) {
          params.market = marketId;
        }

        const historicalData = await api.getPriceTrends(params);
        
        if (!historicalData || historicalData.length < 5) {
          setError('Insufficient data for predictions');
          return;
        }

        // Prepare data for predictions
        const processedData = historicalData.map(item => ({
          date: item.date,
          avg_price: (parseFloat(item.avg_min_price || 0) + parseFloat(item.avg_max_price || 0)) / 2,
          value: (parseFloat(item.avg_min_price || 0) + parseFloat(item.avg_max_price || 0)) / 2
        })).filter(item => item.avg_price > 0);

        // Generate predictions
        const predictionData = generatePricePredictions(processedData, 14); // 2 weeks ahead
        setPredictions(predictionData);

        // Generate summary
        const summary = generatePredictionSummary(predictionData);
        setPredictionSummary(summary);

        // Analyze seasonal patterns
        const seasonal = analyzeSeasonalPatterns(processedData);
        setSeasonalAnalysis(seasonal);

      } catch (err) {
        console.error('Error generating predictions:', err);
        setError('Failed to generate predictions');
      } finally {
        setLoading(false);
      }
    };

    fetchPredictions();
  }, [commodityId, marketId, priceUnit]);

  const getConfidenceColor = (confidence) => {
    if (confidence >= 70) return 'text-green-600 bg-green-100';
    if (confidence >= 50) return 'text-yellow-600 bg-yellow-100';
    return 'text-red-600 bg-red-100';
  };

  const getTrendIcon = (trend) => {
    switch (trend) {
      case 'increasing':
        return <TrendingUp className="h-5 w-5 text-green-600" />;
      case 'decreasing':
        return <TrendingDown className="h-5 w-5 text-red-600" />;
      default:
        return <Activity className="h-5 w-5 text-gray-600" />;
    }
  };

  const formatPredictionDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric',
      weekday: 'short'
    });
  };

  if (loading) {
    return (
      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex items-center space-x-2 mb-4">
          <Brain className="h-5 w-5 text-purple-600" />
          <h3 className="text-lg font-semibold text-gray-900">Price Predictions</h3>
        </div>
        <LoadingSpinner size="md" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex items-center space-x-2 mb-4">
          <Brain className="h-5 w-5 text-purple-600" />
          <h3 className="text-lg font-semibold text-gray-900">Price Predictions</h3>
        </div>
        <div className="flex items-center space-x-2 text-red-600">
          <AlertCircle className="h-4 w-4" />
          <span className="text-sm">{error}</span>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-2">
          <Brain className="h-5 w-5 text-purple-600" />
          <h3 className="text-lg font-semibold text-gray-900">Price Predictions</h3>
        </div>
        
        {predictions && (
          <div className={`px-3 py-1 rounded-full text-xs font-medium ${getConfidenceColor(predictions.confidence)}`}>
            {predictions.confidence.toFixed(0)}% Confidence
          </div>
        )}
      </div>

      {/* Prediction Summary */}
      {predictionSummary && (
        <div className="mb-6 p-4 bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg">
          <div className="flex items-center space-x-3 mb-3">
            {getTrendIcon(predictions?.trend)}
            <div>
              <h4 className="font-medium text-gray-900">{predictionSummary.summary}</h4>
              <p className="text-sm text-gray-600">{predictionSummary.short_term_outlook}</p>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-gray-500">Tomorrow:</span>
              <div className="font-semibold text-purple-700">
                {formatPrice(convertPrice(predictionSummary.next_day_prediction, priceUnit), 'TSh')} per {priceUnit}
              </div>
            </div>
            <div>
              <span className="text-gray-500">Week Ahead:</span>
              <div className="font-semibold text-purple-700">
                {formatPrice(convertPrice(predictionSummary.week_ahead_prediction, priceUnit), 'TSh')} per {priceUnit}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Detailed Predictions */}
      {predictions && predictions.predictions.length > 0 && (
        <div className="mb-6">
          <h4 className="text-sm font-medium text-gray-900 mb-3 flex items-center">
            <Target className="h-4 w-4 mr-2" />
            14-Day Forecast
          </h4>
          
          <div className="space-y-3 max-h-64 overflow-y-auto">
            {predictions.predictions.slice(0, 7).map((pred, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded">
                <div className="flex items-center space-x-3">
                  <div className="text-sm">
                    <div className="font-medium text-gray-900">
                      {formatPredictionDate(pred.date)}
                    </div>
                    <div className="text-xs text-gray-500">
                      {pred.days_ahead} day{pred.days_ahead > 1 ? 's' : ''} ahead
                    </div>
                  </div>
                </div>
                
                <div className="text-right">
                  <div className="font-semibold text-purple-700">
                    {formatPrice(convertPrice(pred.predicted_price, priceUnit), 'TSh')}
                  </div>
                  <div className="text-xs text-gray-500">
                    ±{formatPrice(convertPrice(pred.upper_bound - pred.predicted_price, priceUnit), 'TSh')}
                  </div>
                </div>
                
                <div className={`px-2 py-1 rounded text-xs ${getConfidenceColor(pred.confidence)}`}>
                  {pred.confidence.toFixed(0)}%
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Seasonal Analysis */}
      {seasonalAnalysis && seasonalAnalysis.seasonal_trend !== 'insufficient_data' && (
        <div className="border-t pt-4">
          <h4 className="text-sm font-medium text-gray-900 mb-3 flex items-center">
            <Calendar className="h-4 w-4 mr-2" />
            Seasonal Patterns
          </h4>
          
          <div className="text-sm text-gray-600">
            {seasonalAnalysis.seasonal_trend === 'detected' ? (
              <div className="space-y-2">
                {seasonalAnalysis.peak_months.length > 0 && (
                  <p>
                    <span className="font-medium text-green-700">Peak months:</span>{' '}
                    {seasonalAnalysis.peak_months.map(month => 
                      new Date(0, month).toLocaleDateString('en-US', { month: 'long' })
                    ).join(', ')}
                  </p>
                )}
                {seasonalAnalysis.low_months.length > 0 && (
                  <p>
                    <span className="font-medium text-blue-700">Low months:</span>{' '}
                    {seasonalAnalysis.low_months.map(month => 
                      new Date(0, month).toLocaleDateString('en-US', { month: 'long' })
                    ).join(', ')}
                  </p>
                )}
              </div>
            ) : (
              <p>No significant seasonal patterns detected in available data.</p>
            )}
          </div>
        </div>
      )}

      {/* Methodology Info */}
      <div className="mt-4 pt-4 border-t border-gray-200">
        <div className="text-xs text-gray-500">
          <p className="mb-1">
            <strong>Methodology:</strong> Linear regression with volatility adjustment
          </p>
          <p>
            Predictions are based on historical price trends and may not account for external market factors.
          </p>
        </div>
      </div>
    </div>
  );
}
