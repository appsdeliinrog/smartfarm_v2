import { useState, useEffect } from 'react';
import { api } from '../api';
import { formatPrice } from '../utils/format';
import { convertPrice, getUnitDisplayText } from '../utils/priceUtils';
import { TrendingUp, TrendingDown, Target, AlertTriangle, Activity, ChevronDown, ChevronUp } from 'lucide-react';

export function SmartAlerts({ priceUnit = 'kg' }) {
  const [alerts, setAlerts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isExpanded, setIsExpanded] = useState(false);

  useEffect(() => {
    generateSmartAlerts();
  }, [priceUnit]); // This will trigger when priceUnit changes

  const generateSmartAlerts = async () => {
    setLoading(true);
    try {
      // Get real data from API
      const [latestPrices, commodities] = await Promise.all([
        api.getLatestPrices(),
        api.getCommodities(),
      ]);

      const alertsGenerated = [];
      const priceData = latestPrices || [];
      const commoditiesData = commodities?.results || commodities || [];

      // Process each commodity for real alerts
      for (const commodity of commoditiesData.slice(0, 5)) {
        try {
          // Get price trends for this commodity
          const trends = await api.getPriceTrends({ commodity: commodity.id, days: 30 });
          
          if (trends && trends.length > 0) {
            // Calculate price statistics
            const recentPrices = trends.slice(0, 7); // Last 7 days
            const olderPrices = trends.slice(7, 14); // Previous 7 days
            
            if (recentPrices.length > 0 && olderPrices.length > 0) {
              const recentAvg = recentPrices.reduce((sum, item) => {
                const price = (parseFloat(item.avg_min_price || 0) + parseFloat(item.avg_max_price || 0)) / 2;
                return sum + price;
              }, 0) / recentPrices.length;

              const olderAvg = olderPrices.reduce((sum, item) => {
                const price = (parseFloat(item.avg_min_price || 0) + parseFloat(item.avg_max_price || 0)) / 2;
                return sum + price;
              }, 0) / olderPrices.length;

              if (recentAvg > 0 && olderAvg > 0) {
                const priceChange = ((recentAvg - olderAvg) / olderAvg) * 100;
                
                // Generate price trend alerts
                if (Math.abs(priceChange) > 10) {
                  alertsGenerated.push({
                    id: `trend-${commodity.id}`,
                    type: 'trend',
                    priority: Math.abs(priceChange) > 20 ? 'high' : 'medium',
                    commodity: commodity.name,
                    title: priceChange > 0 ? 'PRICE SURGE' : 'PRICE DROP',
                    message: `${Math.abs(priceChange).toFixed(1)}% ${priceChange > 0 ? 'increase' : 'decrease'} in 7 days`,
                    price: recentAvg,
                    change: priceChange,
                    icon: priceChange > 0 ? TrendingUp : TrendingDown,
                    timestamp: new Date().toISOString()
                  });
                }

                // Check for volatility
                const priceVariance = recentPrices.reduce((sum, item) => {
                  const price = (parseFloat(item.avg_min_price || 0) + parseFloat(item.avg_max_price || 0)) / 2;
                  return sum + Math.pow(price - recentAvg, 2);
                }, 0) / recentPrices.length;
                
                const volatility = Math.sqrt(priceVariance) / recentAvg * 100;
                
                if (volatility > 15) {
                  alertsGenerated.push({
                    id: `volatility-${commodity.id}`,
                    type: 'volatility',
                    priority: volatility > 25 ? 'high' : 'medium',
                    commodity: commodity.name,
                    title: 'HIGH VOLATILITY',
                    message: `${volatility.toFixed(1)}% volatility - Market unstable`,
                    price: recentAvg,
                    volatility: volatility,
                    icon: AlertTriangle,
                    timestamp: new Date().toISOString()
                  });
                }
              }
            }
          }

          // Add market comparison alerts
          const commodityPrices = priceData.filter(p => p.commodity_name === commodity.name);
          if (commodityPrices.length > 1) {
            const prices = commodityPrices.map(p => ({
              market: p.market_name,
              price: parseFloat(p.price) || 0
            })).filter(p => p.price > 0);

            if (prices.length > 1) {
              const maxPrice = Math.max(...prices.map(p => p.price));
              const minPrice = Math.min(...prices.map(p => p.price));
              const priceDiff = ((maxPrice - minPrice) / minPrice) * 100;

              if (priceDiff > 15) {
                const bestMarket = prices.find(p => p.price === maxPrice);
                const worstMarket = prices.find(p => p.price === minPrice);

                alertsGenerated.push({
                  id: `opportunity-${commodity.id}`,
                  type: 'opportunity',
                  priority: 'high',
                  commodity: commodity.name,
                  title: 'ARBITRAGE OPPORTUNITY',
                  message: `${priceDiff.toFixed(1)}% spread: ${bestMarket.market} vs ${worstMarket.market}`,
                  bestMarket: bestMarket.market,
                  bestPrice: maxPrice,
                  worstMarket: worstMarket.market,
                  worstPrice: minPrice,
                  savings: priceDiff,
                  icon: Target,
                  timestamp: new Date().toISOString()
                });
              }
            }
          }
        } catch (error) {
          console.error(`Error processing commodity ${commodity.id}:`, error);
        }
      }

      // Sort alerts by priority and recency
      const sortedAlerts = alertsGenerated
        .sort((a, b) => {
          const priorityOrder = { high: 3, medium: 2, low: 1 };
          if (priorityOrder[a.priority] !== priorityOrder[b.priority]) {
            return priorityOrder[b.priority] - priorityOrder[a.priority];
          }
          return new Date(b.timestamp) - new Date(a.timestamp);
        })
        .slice(0, 10); // Limit to 10 alerts

      setAlerts(sortedAlerts);
    } catch (error) {
      console.error('Error generating smart alerts:', error);
      setAlerts([]);
    } finally {
      setLoading(false);
    }
  };

  const formatAlertTime = () => {
    const now = new Date();
    return now.toLocaleTimeString('en-US', { 
      hour12: false, 
      hour: '2-digit', 
      minute: '2-digit',
      second: '2-digit'
    });
  };

  const getAlertTypeColor = (type) => {
    const colors = {
      trend: 'text-cyan-400',
      volatility: 'text-amber-400',
      opportunity: 'text-purple-400'
    };
    return colors[type] || 'text-green-400';
  };

  const getPriorityIndicator = (priority) => {
    if (priority === 'high') return 'bg-red-500';
    if (priority === 'medium') return 'bg-amber-500';
    return 'bg-green-500';
  };

  if (loading) {
    return (
      <div className="bg-gradient-to-r from-slate-900 to-slate-800 rounded-lg border border-slate-700 p-4">
        <div className="flex items-center space-x-2 mb-3">
          <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
          <span className="text-green-400 text-sm font-mono tracking-wider">MARKET INTELLIGENCE</span>
          <div className="flex-1 h-px bg-slate-700"></div>
          <span className="text-slate-400 text-xs font-mono">{formatAlertTime()}</span>
        </div>
        <div className="flex items-center py-4">
          <div className="animate-spin rounded-full h-4 w-4 border border-green-400 border-t-transparent"></div>
          <span className="ml-3 text-slate-300 text-sm font-mono">ANALYZING MARKET DATA...</span>
        </div>
      </div>
    );
  }

  if (alerts.length === 0) {
    return (
      <div className="bg-gradient-to-r from-slate-900 to-slate-800 rounded-lg border border-slate-700 p-4">
        <div className="flex items-center space-x-2 mb-3">
          <div className="w-2 h-2 bg-green-400 rounded-full"></div>
          <span className="text-green-400 text-sm font-mono tracking-wider">MARKET INTELLIGENCE</span>
          <div className="flex-1 h-px bg-slate-700"></div>
          <span className="text-slate-400 text-xs font-mono">{formatAlertTime()}</span>
        </div>
        <div className="text-center py-6">
          <Activity className="h-8 w-8 text-slate-600 mx-auto mb-2" />
          <p className="text-slate-400 text-sm font-mono">NO ALERTS | MARKETS STABLE</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gradient-to-r from-slate-900 to-slate-800 rounded-lg border border-slate-700 overflow-hidden">
      {/* Bloomberg-style Header - Always Visible and Clickable */}
      <div 
        className="p-4 border-b border-slate-700 cursor-pointer hover:bg-slate-800/30 transition-colors"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
            <span className="text-green-400 text-sm font-mono tracking-wider">MARKET INTELLIGENCE</span>
            <span className="text-slate-400 text-xs font-mono">|</span>
            <span className="text-amber-400 text-xs font-mono">{alerts.length} ALERTS</span>
            {loading && (
              <div className="animate-spin rounded-full h-3 w-3 border border-green-400 border-t-transparent ml-2"></div>
            )}
          </div>
          <div className="flex items-center space-x-3">
            <button
              onClick={(e) => {
                e.stopPropagation();
                generateSmartAlerts();
              }}
              className="text-slate-400 hover:text-green-400 transition-colors"
              title="Refresh alerts"
            >
              <Activity className="h-4 w-4" />
            </button>
            <span className="text-slate-400 text-xs font-mono">{formatAlertTime()}</span>
            <div className="text-slate-400">
              {isExpanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
            </div>
          </div>
        </div>
        
        {/* Summary when collapsed */}
        {!isExpanded && alerts.length > 0 && (
          <div className="mt-2 text-xs text-slate-400 font-mono">
            Click to view {alerts.length} market alerts • 
            {alerts.filter(a => a.priority === 'high').length} high priority • 
            {alerts.filter(a => a.priority === 'medium').length} medium priority
          </div>
        )}
      </div>

      {/* Expandable Alerts Content */}
      {isExpanded && (
        <>
          {alerts.length === 0 ? (
            <div className="text-center py-6">
              <Activity className="h-8 w-8 text-slate-600 mx-auto mb-2" />
              <p className="text-slate-400 text-sm font-mono">NO ALERTS | MARKETS STABLE</p>
            </div>
          ) : (
            /* Alerts Stream */
            <div className="max-h-64 overflow-y-auto" style={{
              scrollbarWidth: 'thin',
              scrollbarColor: '#64748b #1e293b'
            }}>
              {alerts.map((alert) => {
                const IconComponent = alert.icon;
                return (
                  <div
                    key={alert.id}
                    className="border-b border-slate-800 last:border-b-0 transition-colors cursor-pointer"
                    style={{
                      backgroundColor: 'transparent',
                      '&:hover': {
                        backgroundColor: 'rgba(30, 41, 59, 0.5)'
                      }
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.backgroundColor = 'rgba(30, 41, 59, 0.5)';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.backgroundColor = 'transparent';
                    }}
                  >
                    <div className="p-3 flex items-start space-x-3">
                      {/* Priority Bar */}
                      <div 
                        className={`w-1 h-12 rounded-full flex-shrink-0 mt-1`}
                        style={{
                          backgroundColor: 
                            alert.priority === 'high' ? '#ef4444' : 
                            alert.priority === 'medium' ? '#f59e0b' : '#10b981'
                        }}
                      ></div>
                      
                      {/* Alert Icon */}
                      <div 
                        className="flex-shrink-0 mt-1"
                        style={{
                          color: 
                            alert.type === 'trend' ? '#06b6d4' :
                            alert.type === 'volatility' ? '#f59e0b' :
                            alert.type === 'opportunity' ? '#a855f7' : '#10b981'
                        }}
                      >
                        <IconComponent className="h-4 w-4" />
                      </div>
                      
                      {/* Alert Content */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-1">
                          <span 
                            className="text-sm font-mono font-semibold truncate"
                            style={{ color: '#10b981' }}
                          >
                            {alert.commodity}
                          </span>
                          <span 
                            className="text-xs font-mono whitespace-nowrap ml-2"
                            style={{ color: '#94a3b8' }}
                          >
                            {alert.priority.toUpperCase()}
                          </span>
                        </div>
                        
                        <p 
                          className="text-xs font-mono mb-2 leading-relaxed"
                          style={{ color: '#cbd5e1' }}
                        >
                          {alert.title}: {alert.message}
                        </p>
                        
                        {/* Alert Details */}
                        <div className="flex flex-wrap items-center gap-3 text-xs">
                          {alert.price && (
                            <span 
                              className="font-mono"
                              style={{ color: '#10b981' }}
                            >
                              {formatPrice(convertPrice(alert.price, priceUnit), 'TSh')} {getUnitDisplayText(priceUnit)}
                            </span>
                          )}
                          {alert.change && (
                            <span 
                              className="font-mono"
                              style={{ 
                                color: alert.change > 0 ? '#10b981' : '#ef4444'
                              }}
                            >
                              {alert.change > 0 ? '+' : ''}{alert.change.toFixed(1)}%
                            </span>
                          )}
                          {alert.bestMarket && (
                            <span 
                              className="font-mono"
                              style={{ color: '#a855f7' }}
                            >
                              Best: {alert.bestMarket}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </>
      )}
    </div>
  );
}
