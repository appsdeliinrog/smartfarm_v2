import { useState, useEffect } from 'react';
import { Modal } from './common/Modal';
import { api } from '../api';
import { formatPrice } from '../utils/format';
import { convertPrice, getUnitDisplayText } from '../utils/priceUtils';
import { TrendingUp, TrendingDown, Minus, BarChart3, Search } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export function CommodityAnalysisModal({ isOpen, onClose, priceUnit = 'kg' }) {
  const [commodities, setCommodities] = useState([]);
  const [commodityStats, setCommodityStats] = useState({});
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    if (isOpen) {
      fetchCommodityData();
    }
  }, [isOpen]);

  const fetchCommodityData = async () => {
    setLoading(true);
    try {
      // Fetch commodities and their price summaries
      const [commoditiesRes, summaryRes] = await Promise.all([
        api.getCommodities(),
        api.getPriceSummary(),
      ]);

      const commoditiesData = commoditiesRes.results || commoditiesRes;
      setCommodities(commoditiesData);

      // Process summary data to get stats per commodity
      const statsMap = {};
      
      for (const commodity of commoditiesData) {
        // Get recent price trends for this commodity
        try {
          const trendData = await api.getPriceTrends({ 
            commodity: commodity.id, 
            days: 7 
          });

          if (trendData && trendData.length > 0) {
            // Calculate average price and trend
            const prices = trendData.map(item => {
              const minPrice = parseFloat(item.avg_min_price || 0);
              const maxPrice = parseFloat(item.avg_max_price || 0);
              return (minPrice + maxPrice) / 2;
            }).filter(price => price > 0);

            if (prices.length > 0) {
              const avgPrice = prices.reduce((sum, p) => sum + p, 0) / prices.length;
              const firstPrice = prices[prices.length - 1];
              const lastPrice = prices[0];
              const priceChange = lastPrice - firstPrice;
              const priceChangePercent = firstPrice > 0 ? (priceChange / firstPrice) * 100 : 0;

              statsMap[commodity.id] = {
                averagePrice: avgPrice,
                priceChange: priceChangePercent,
                dataPoints: trendData.length,
                trend: priceChangePercent > 0 ? 'up' : priceChangePercent < 0 ? 'down' : 'neutral'
              };
            }
          }
        } catch (error) {
          console.error(`Error fetching trends for commodity ${commodity.id}:`, error);
          statsMap[commodity.id] = {
            averagePrice: 0,
            priceChange: 0,
            dataPoints: 0,
            trend: 'neutral'
          };
        }
      }

      setCommodityStats(statsMap);
    } catch (error) {
      console.error('Error fetching commodity data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleViewDetails = (commodityId) => {
    onClose();
    navigate(`/charts?commodity=${commodityId}`);
  };

  const filteredCommodities = commodities.filter(commodity =>
    commodity.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    commodity.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getTrendIcon = (trend) => {
    if (trend === 'up') return <TrendingUp className="h-4 w-4 text-green-500" />;
    if (trend === 'down') return <TrendingDown className="h-4 w-4 text-red-500" />;
    return <Minus className="h-4 w-4 text-gray-400" />;
  };

  const getTrendColor = (trend) => {
    if (trend === 'up') return 'text-green-600';
    if (trend === 'down') return 'text-red-600';
    return 'text-gray-500';
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Commodity Analysis" size="lg">
      <div className="space-y-4">
        {/* Search and Filter */}
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-gray-400" />
          </div>
          <input
            type="text"
            className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-green-500 focus:border-green-500"
            placeholder="Search commodities..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        {/* Summary Stats */}
        <div className="bg-gray-50 rounded-lg p-4">
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-2xl font-semibold text-gray-900">{commodities.length}</div>
              <div className="text-sm text-gray-500">Total Commodities</div>
            </div>
            <div>
              <div className="text-2xl font-semibold text-gray-900">
                {Object.values(commodityStats).filter(stat => stat.averagePrice > 0).length}
              </div>
              <div className="text-sm text-gray-500">With Price Data</div>
            </div>
            <div>
              <div className="text-2xl font-semibold text-gray-900">
                {Object.values(commodityStats).filter(stat => stat.trend === 'up').length}
              </div>
              <div className="text-sm text-gray-500">Trending Up</div>
            </div>
          </div>
        </div>

        {/* Commodities List */}
        <div className="max-h-96 overflow-y-auto">
          {loading ? (
            <div className="space-y-3">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="bg-white border border-gray-200 rounded-lg p-4 animate-pulse">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="h-4 bg-gray-200 rounded w-1/3 mb-2"></div>
                      <div className="h-3 bg-gray-200 rounded w-1/4"></div>
                    </div>
                    <div className="h-8 bg-gray-200 rounded w-20"></div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="space-y-2">
              {filteredCommodities.map((commodity) => {
                const stats = commodityStats[commodity.id] || {};
                return (
                  <div
                    key={commodity.id}
                    className="bg-white border border-gray-200 rounded-lg p-4 hover:border-green-300 hover:shadow-sm transition-all cursor-pointer"
                    onClick={() => handleViewDetails(commodity.id)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <h4 className="text-sm font-medium text-gray-900">
                            {commodity.name}
                          </h4>
                          <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                            {commodity.category}
                          </span>
                        </div>
                        <div className="flex items-center gap-4 mt-1">
                          {stats.averagePrice > 0 ? (
                            <>
                              <span className="text-sm text-gray-600">
                                Avg: {formatPrice(convertPrice(stats.averagePrice, priceUnit), 'TSh')} {getUnitDisplayText(priceUnit)}
                              </span>
                              <div className="flex items-center gap-1">
                                {getTrendIcon(stats.trend)}
                                <span className={`text-xs font-medium ${getTrendColor(stats.trend)}`}>
                                  {stats.trend !== 'neutral' && (stats.trend === 'up' ? '+' : '')}
                                  {Math.abs(stats.priceChange).toFixed(1)}%
                                </span>
                              </div>
                              <span className="text-xs text-gray-500">
                                {stats.dataPoints} data points
                              </span>
                            </>
                          ) : (
                            <span className="text-sm text-gray-500">No recent price data</span>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center">
                        <button className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500">
                          <BarChart3 className="h-4 w-4 mr-1" />
                          View Details
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {filteredCommodities.length === 0 && !loading && (
          <div className="text-center py-8">
            <div className="text-gray-500">No commodities found matching your search.</div>
          </div>
        )}
      </div>
    </Modal>
  );
}
