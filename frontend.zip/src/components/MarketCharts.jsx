import React from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  LineElement,
  PointElement,
} from 'chart.js';
import { Bar, Line } from 'react-chartjs-2';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  LineElement,
  PointElement,
  Title,
  Tooltip,
  Legend
);

export function PriceComparisonChart({ marketData, priceUnit }) {
  if (!marketData || marketData.length === 0) {
    return <div className="text-center text-gray-500 py-8">No data to display</div>;
  }

  const formatPrice = (price) => {
    if (!price) return 0;
    return priceUnit === '100kg' ? price * 100 : price;
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('en-TZ', {
      style: 'currency',
      currency: 'TZS',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  // Prepare data for buy/sell price comparison
  const chartData = {
    labels: marketData.map(market => `${market.market_name}\n(${market.region_name})`),
    datasets: [
      {
        label: `Buy Price (${priceUnit})`,
        data: marketData.map(market => formatPrice(market.latest_buy_price || 0)),
        backgroundColor: 'rgba(34, 197, 94, 0.8)',
        borderColor: 'rgba(34, 197, 94, 1)',
        borderWidth: 2,
        borderRadius: 4,
      },
      {
        label: `Sell Price (${priceUnit})`,
        data: marketData.map(market => formatPrice(market.latest_sell_price || 0)),
        backgroundColor: 'rgba(59, 130, 246, 0.8)',
        borderColor: 'rgba(59, 130, 246, 1)',
        borderWidth: 2,
        borderRadius: 4,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: true,
        text: `Price Comparison Across Markets (per ${priceUnit})`,
        font: {
          size: 16,
          weight: 'bold',
        },
      },
      tooltip: {
        callbacks: {
          label: function(context) {
            return `${context.dataset.label}: ${formatCurrency(context.parsed.y)}`;
          },
        },
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          callback: function(value) {
            return formatCurrency(value);
          },
        },
        title: {
          display: true,
          text: 'Price (TZS)',
        },
      },
      x: {
        title: {
          display: true,
          text: 'Markets',
        },
      },
    },
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm">
      <h4 className="text-lg font-semibold text-gray-900 mb-4">📊 Price Comparison</h4>
      <div id="price-comparison-chart" style={{ height: '400px' }}>
        <Bar data={chartData} options={options} />
      </div>
    </div>
  );
}

export function ProfitMarginChart({ marketData, priceUnit }) {
  if (!marketData || marketData.length === 0) {
    return <div className="text-center text-gray-500 py-8">No data to display</div>;
  }

  const formatPrice = (price) => {
    if (!price) return 0;
    return priceUnit === '100kg' ? price * 100 : price;
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('en-TZ', {
      style: 'currency',
      currency: 'TZS',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  // Sort by profit margin for better visualization
  const sortedData = [...marketData].sort((a, b) => b.profit_margin - a.profit_margin);

  const chartData = {
    labels: sortedData.map(market => `${market.market_name}\n(${market.region_name})`),
    datasets: [
      {
        label: `Profit Margin (${priceUnit})`,
        data: sortedData.map(market => formatPrice(market.profit_margin || 0)),
        backgroundColor: sortedData.map((_, index) => {
          if (index === 0) return 'rgba(34, 197, 94, 0.8)'; // Green for highest
          if (index === 1) return 'rgba(59, 130, 246, 0.8)'; // Blue for second
          if (index === 2) return 'rgba(168, 85, 247, 0.8)'; // Purple for third
          return 'rgba(156, 163, 175, 0.8)'; // Gray for others
        }),
        borderColor: sortedData.map((_, index) => {
          if (index === 0) return 'rgba(34, 197, 94, 1)';
          if (index === 1) return 'rgba(59, 130, 246, 1)';
          if (index === 2) return 'rgba(168, 85, 247, 1)';
          return 'rgba(156, 163, 175, 1)';
        }),
        borderWidth: 2,
        borderRadius: 4,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      title: {
        display: true,
        text: `Profit Margins by Market (per ${priceUnit})`,
        font: {
          size: 16,
          weight: 'bold',
        },
      },
      tooltip: {
        callbacks: {
          label: function(context) {
            const market = sortedData[context.dataIndex];
            return [
              `Profit Margin: ${formatCurrency(context.parsed.y)}`,
              `Buy: ${formatCurrency(formatPrice(market.latest_buy_price || 0))}`,
              `Sell: ${formatCurrency(formatPrice(market.latest_sell_price || 0))}`,
            ];
          },
        },
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          callback: function(value) {
            return formatCurrency(value);
          },
        },
        title: {
          display: true,
          text: 'Profit Margin (TZS)',
        },
      },
      x: {
        title: {
          display: true,
          text: 'Markets (Ranked by Profitability)',
        },
      },
    },
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm">
      <h4 className="text-lg font-semibold text-gray-900 mb-4">💰 Profit Margins</h4>
      <div id="profit-margin-chart" style={{ height: '400px' }}>
        <Bar data={chartData} options={options} />
      </div>
    </div>
  );
}

export function VolatilityChart({ marketData }) {
  if (!marketData || marketData.length === 0) {
    return <div className="text-center text-gray-500 py-8">No data to display</div>;
  }

  const volatilityScore = (volatility) => {
    switch (volatility) {
      case 'Low': return 1;
      case 'Medium': return 2;
      case 'High': return 3;
      default: return 0;
    }
  };

  const chartData = {
    labels: marketData.map(market => `${market.market_name}\n(${market.region_name})`),
    datasets: [
      {
        label: 'Price Volatility Score',
        data: marketData.map(market => volatilityScore(market.volatility)),
        backgroundColor: marketData.map(market => {
          switch (market.volatility) {
            case 'Low': return 'rgba(34, 197, 94, 0.8)';
            case 'Medium': return 'rgba(251, 191, 36, 0.8)';
            case 'High': return 'rgba(239, 68, 68, 0.8)';
            default: return 'rgba(156, 163, 175, 0.8)';
          }
        }),
        borderColor: marketData.map(market => {
          switch (market.volatility) {
            case 'Low': return 'rgba(34, 197, 94, 1)';
            case 'Medium': return 'rgba(251, 191, 36, 1)';
            case 'High': return 'rgba(239, 68, 68, 1)';
            default: return 'rgba(156, 163, 175, 1)';
          }
        }),
        borderWidth: 2,
        borderRadius: 4,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      title: {
        display: true,
        text: 'Market Price Volatility Assessment',
        font: {
          size: 16,
          weight: 'bold',
        },
      },
      tooltip: {
        callbacks: {
          label: function(context) {
            const market = marketData[context.dataIndex];
            return [
              `Volatility: ${market.volatility}`,
              `Data Points: ${market.data_points}`,
              `Risk Level: ${market.volatility === 'Low' ? 'Stable' : market.volatility === 'Medium' ? 'Moderate Risk' : 'High Risk'}`
            ];
          },
        },
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        max: 3.5,
        ticks: {
          stepSize: 1,
          callback: function(value) {
            switch (value) {
              case 1: return 'Low';
              case 2: return 'Medium';
              case 3: return 'High';
              default: return '';
            }
          },
        },
        title: {
          display: true,
          text: 'Volatility Level',
        },
      },
      x: {
        title: {
          display: true,
          text: 'Markets',
        },
      },
    },
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm">
      <h4 className="text-lg font-semibold text-gray-900 mb-4">📈 Market Volatility</h4>
      <div id="volatility-chart" style={{ height: '350px' }}>
        <Bar data={chartData} options={options} />
      </div>
    </div>
  );
}
