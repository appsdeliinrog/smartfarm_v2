import { useState, useEffect } from 'react';
import { api } from '../api';
import { convertPrice, getUnitDisplayText } from '../utils/priceUtils';
import { PriceComparisonChart, ProfitMarginChart, VolatilityChart } from './MarketCharts';
import { ExportButtons } from './ExportButtons';
import { SavedComparisons } from './SavedComparisons';

export function MarketComparison({ priceUnit = 'kg' }) {
  const [commodities, setCommodities] = useState([]);
  const [markets, setMarkets] = useState([]);
  const [selectedCommodity, setSelectedCommodity] = useState('');
  const [selectedMarkets, setSelectedMarkets] = useState([]);
  const [comparisonData, setComparisonData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [viewMode, setViewMode] = useState('charts'); // 'charts' or 'table'
  const [selectedDays, setSelectedDays] = useState(7); // Default to 7 days
  const [showDateDropdown, setShowDateDropdown] = useState(false);
  const [customStartDate, setCustomStartDate] = useState('');
  const [customEndDate, setCustomEndDate] = useState('');
  const [isCustomRange, setIsCustomRange] = useState(false);

  // Load commodities and markets on component mount
  useEffect(() => {
    const loadData = async () => {
      try {
        const [commoditiesRes, marketsRes] = await Promise.all([
          api.getCommodities(),
          api.getMarkets(),
        ]);
        setCommodities(commoditiesRes.results || commoditiesRes);
        
        // Process markets data to ensure region information is available
        const marketsData = marketsRes.results || marketsRes;
        setMarkets(marketsData);
      } catch (err) {
        console.error('Error loading data:', err);
      }
    };
    loadData();
  }, []);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (showDateDropdown && !event.target.closest('.date-dropdown')) {
        setShowDateDropdown(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [showDateDropdown]);

  const handleDateRangeChange = async (days) => {
    if (days === 'custom') {
      setIsCustomRange(true);
      setShowDateDropdown(false);
      return;
    }
    
    setIsCustomRange(false);
    setSelectedDays(days);
    setShowDateDropdown(false);
    
    // If we have comparison data, refresh it with new date range
    if (selectedCommodity && selectedMarkets.length >= 2) {
      await handleCompareWithDays(days);
    }
  };

  const handleCustomDateApply = async () => {
    if (!customStartDate || !customEndDate) {
      setError('Please select both start and end dates.');
      return;
    }

    const startDate = new Date(customStartDate);
    const endDate = new Date(customEndDate);
    const daysDiff = Math.ceil((endDate - startDate) / (1000 * 60 * 60 * 24));

    if (daysDiff < 1) {
      setError('End date must be after start date.');
      return;
    }

    if (daysDiff > 365) {
      setError('Date range cannot exceed 365 days.');
      return;
    }

    setIsCustomRange(false);
    setSelectedDays(daysDiff);
    
    if (selectedCommodity && selectedMarkets.length >= 2) {
      await handleCompareWithDays(daysDiff);
    }
  };

  const handleCustomDateCancel = () => {
    setIsCustomRange(false);
    setCustomStartDate('');
    setCustomEndDate('');
  };

  const handleCompareWithDays = async (days = selectedDays) => {
    if (!selectedCommodity || selectedCommodity === '' || selectedMarkets.length < 2) {
      setError('Please select a commodity and at least 2 markets to compare');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const response = await api.compareMarkets({
        commodity: parseInt(selectedCommodity),
        markets: selectedMarkets.map(id => parseInt(id)),
        days: days
      });
      setComparisonData(response);
    } catch (err) {
      setError('Failed to load comparison data. Please try again.');
      console.error('Error loading comparison data:', err);
    } finally {
      setLoading(false);
    }
  };

  const getDateRangeText = () => {
    if (isCustomRange) {
      return 'Custom Range';
    }
    
    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(endDate.getDate() - selectedDays + 1);
    
    return `${startDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} - ${endDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}`;
  };

  const handleCommodityChange = (commodityId) => {
    setSelectedCommodity(commodityId);
    setComparisonData(null);
    setSelectedMarkets([]);
  };

  const handleMarketToggle = (marketId) => {
    setSelectedMarkets(prev => {
      const isSelected = prev.includes(marketId);
      if (isSelected) {
        return prev.filter(id => id !== marketId);
      } else if (prev.length < 5) { // Limit to 5 markets
        return [...prev, marketId];
      }
      return prev;
    });
  };

  const handleCompare = async () => {
    await handleCompareWithDays();
  };

  const handleLoadComparison = async (savedComparison) => {
    try {
      // Set the saved state
      setSelectedCommodity(savedComparison.selectedCommodity);
      setSelectedMarkets(savedComparison.selectedMarkets);
      
      // Load the comparison data
      setLoading(true);
      const response = await api.compareMarkets({
        commodity: parseInt(savedComparison.selectedCommodity),
        markets: savedComparison.selectedMarkets.map(id => parseInt(id))
      });
      setComparisonData(response);
      setViewMode('charts'); // Show charts by default
    } catch (err) {
      setError('Failed to load saved comparison. Please try again.');
      console.error('Error loading saved comparison:', err);
    } finally {
      setLoading(false);
    }
  };

  const formatPrice = (price) => {
    if (!price) return 'N/A';
    return new Intl.NumberFormat('en-TZ', {
      style: 'currency',
      currency: 'TZS',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(convertPrice(price, priceUnit));
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const getRankBadge = (rank, type) => {
    if (!rank) return null;
    
    const colors = {
      1: 'bg-green-100 text-green-800',
      2: 'bg-blue-100 text-blue-800',
      3: 'bg-purple-100 text-purple-800'
    };
    const color = colors[rank] || 'bg-gray-100 text-gray-800';
    const label = type === 'buy' ? 'Best Buy' : type === 'sell' ? 'Best Sell' : 'Most Profitable';
    
    return rank <= 3 ? (
      <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${color} mb-1`}>
        #{rank} {rank === 1 ? label : ''}
      </span>
    ) : (
      <span className="inline-flex items-center px-2 py-1 rounded-full text-xs text-gray-500 bg-gray-100 mb-1">
        #{rank}
      </span>
    );
  };

  const getVolatilityColor = (volatility) => {
    switch (volatility) {
      case 'Low': return 'text-green-600';
      case 'Medium': return 'text-yellow-600';
      case 'High': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  return (
    <div className="space-y-6">
      {/* Saved Comparisons */}
      <SavedComparisons onLoadComparison={handleLoadComparison} />

      {/* Header and Controls */}
      <div className="bg-white rounded-lg shadow-sm p-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">🔍 Market Comparison Tool</h2>
        <p className="text-gray-600 mb-6">
          Compare up to 5 markets side-by-side to find the best trading opportunities
        </p>

        {/* Commodity Selection */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Select Commodity:
            </label>
            <select
              value={selectedCommodity}
              onChange={(e) => handleCommodityChange(e.target.value)}
              className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
            >
              <option value="">Choose a commodity...</option>
              {commodities.map((commodity) => (
                <option key={commodity.id} value={commodity.id}>
                  {commodity.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Select Markets to Compare ({selectedMarkets.length}/5):
            </label>
            <div className="max-h-32 overflow-y-auto border border-gray-300 rounded-md p-2">
              {markets.map((market) => (
                <label key={market.id} className="flex items-center space-x-2 py-1">
                  <input
                    type="checkbox"
                    checked={selectedMarkets.includes(market.id)}
                    onChange={() => handleMarketToggle(market.id)}
                    disabled={!selectedMarkets.includes(market.id) && selectedMarkets.length >= 5}
                    className="rounded border-gray-300 text-green-600 focus:ring-green-500"
                  />
                  <span className="text-sm text-gray-700">
                    {market.name}, {market.region_name || 'Unknown Region'}
                  </span>
                </label>
              ))}
            </div>
          </div>
        </div>

        {/* Compare Button */}
        <div className="mt-6">
          <button
            onClick={handleCompare}
            disabled={!selectedCommodity || selectedMarkets.length < 2 || loading}
            className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:bg-gray-400 disabled:cursor-not-allowed"
          >
            {loading ? (
              <div className="flex items-center">
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Comparing Markets...
              </div>
            ) : (
              '🔍 Compare Markets'
            )}
          </button>
        </div>
      </div>

      {/* Custom Date Range Modal */}
      {isCustomRange && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-md w-full p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Select Custom Date Range</h3>
            
            <div className="space-y-4">
              <div>
                <label htmlFor="start-date" className="block text-sm font-medium text-gray-700 mb-1">
                  Start Date
                </label>
                <input
                  type="date"
                  id="start-date"
                  value={customStartDate}
                  onChange={(e) => setCustomStartDate(e.target.value)}
                  max={new Date().toISOString().split('T')[0]}
                  className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
                />
              </div>
              
              <div>
                <label htmlFor="end-date" className="block text-sm font-medium text-gray-700 mb-1">
                  End Date
                </label>
                <input
                  type="date"
                  id="end-date"
                  value={customEndDate}
                  onChange={(e) => setCustomEndDate(e.target.value)}
                  max={new Date().toISOString().split('T')[0]}
                  min={customStartDate}
                  className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
                />
              </div>
              
              {customStartDate && customEndDate && (
                <div className="text-sm text-gray-600 bg-gray-50 p-3 rounded-md">
                  📅 Selected range: {new Date(customStartDate).toLocaleDateString('en-US', { 
                    month: 'short', day: 'numeric', year: 'numeric' 
                  })} - {new Date(customEndDate).toLocaleDateString('en-US', { 
                    month: 'short', day: 'numeric', year: 'numeric' 
                  })} ({Math.ceil((new Date(customEndDate) - new Date(customStartDate)) / (1000 * 60 * 60 * 24))} days)
                </div>
              )}
            </div>
            
            <div className="flex justify-end space-x-3 mt-6">
              <button
                onClick={handleCustomDateCancel}
                className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 border border-gray-300 rounded-md hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500"
              >
                Cancel
              </button>
              <button
                onClick={handleCustomDateApply}
                disabled={!customStartDate || !customEndDate}
                className="px-4 py-2 text-sm font-medium text-white bg-green-600 border border-transparent rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Apply Range
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Error State */}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <p className="text-red-700">{error}</p>
        </div>
      )}

      {/* Comparison Results */}
      {comparisonData && !loading && (
        <>
          {/* Summary */}
          {comparisonData.summary && (
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-yellow-800 mb-3">📊 Comparison Summary</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                <div>
                  <p className="font-medium text-yellow-700">💰 Best for Buying:</p>
                  <p className="text-yellow-800">
                    {comparisonData.summary.best_buy_market} - {formatPrice(comparisonData.summary.best_buy_price)}
                  </p>
                </div>
                <div>
                  <p className="font-medium text-yellow-700">📈 Best for Selling:</p>
                  <p className="text-yellow-800">
                    {comparisonData.summary.best_sell_market} - {formatPrice(comparisonData.summary.best_sell_price)}
                  </p>
                </div>
                <div>
                  <p className="font-medium text-yellow-700">🔥 Max Profit Potential:</p>
                  <p className="text-yellow-800 font-bold">
                    {formatPrice(comparisonData.summary.max_arbitrage)} {getUnitDisplayText(priceUnit)}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* View Mode Toggle */}
          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Market Analysis</h3>
              <div className="flex items-center space-x-2">
                {comparisonData && (
                  <div className="relative">
                    <button
                      onClick={() => setShowDateDropdown(!showDateDropdown)}
                      className="date-dropdown inline-flex items-center px-3 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
                    >
                      📅 {selectedDays} days ({getDateRangeText()})
                      <svg className="ml-2 h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                      </svg>
                    </button>
                    
                    {showDateDropdown && (
                      <div className="date-dropdown absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg z-10 border border-gray-200">
                        <div className="py-1">
                          {[7, 14, 30].map((days) => (
                            <button
                              key={days}
                              onClick={() => handleDateRangeChange(days)}
                              className={`block w-full text-left px-4 py-2 text-sm hover:bg-gray-100 ${
                                selectedDays === days && !isCustomRange ? 'bg-green-50 text-green-700 font-medium' : 'text-gray-700'
                              }`}
                            >
                              {days} days ({(() => {
                                const endDate = new Date();
                                const startDate = new Date();
                                startDate.setDate(endDate.getDate() - days + 1);
                                return `${startDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} - ${endDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}`;
                              })()})
                            </button>
                          ))}
                          <div className="border-t border-gray-200 my-1"></div>
                          <button
                            onClick={() => handleDateRangeChange('custom')}
                            className={`block w-full text-left px-4 py-2 text-sm hover:bg-gray-100 ${
                              isCustomRange ? 'bg-green-50 text-green-700 font-medium' : 'text-gray-700'
                            }`}
                          >
                            📅 Custom Range
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                )}
                <button
                  onClick={() => setViewMode('charts')}
                  className={`px-4 py-2 rounded-md text-sm font-medium ${
                    viewMode === 'charts'
                      ? 'bg-green-600 text-white'
                      : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                  }`}
                >
                  📊 Charts View
                </button>
                <button
                  onClick={() => setViewMode('table')}
                  className={`px-4 py-2 rounded-md text-sm font-medium ${
                    viewMode === 'table'
                      ? 'bg-green-600 text-white'
                      : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                  }`}
                >
                  📋 Table View
                </button>
              </div>
            </div>

            {/* Export Buttons */}
            <ExportButtons
              comparisonData={comparisonData}
              selectedCommodity={selectedCommodity}
              selectedMarkets={selectedMarkets}
              commodities={commodities}
              markets={markets}
              priceUnit={priceUnit}
            />

            {viewMode === 'charts' ? (
              /* Charts View */
              <div className="space-y-8">
                {/* Price Comparison Chart */}
                <PriceComparisonChart 
                  marketData={comparisonData.market_analysis} 
                  priceUnit={priceUnit} 
                />
                
                {/* Charts Grid */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <ProfitMarginChart 
                    marketData={comparisonData.market_analysis} 
                    priceUnit={priceUnit} 
                  />
                  <VolatilityChart 
                    marketData={comparisonData.market_analysis} 
                  />
                </div>
              </div>
            ) : (
              /* Table View */
              <div className="overflow-x-auto shadow ring-1 ring-black ring-opacity-5 md:rounded-lg">
                <table className="min-w-full divide-y divide-gray-200 table-fixed">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="w-1/6 px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Market
                      </th>
                      <th className="w-1/6 px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Buy Price
                      </th>
                      <th className="w-1/6 px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Sell Price
                      </th>
                      <th className="w-1/6 px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Profit Margin
                      </th>
                      <th className="w-1/6 px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Volatility
                      </th>
                      <th className="w-1/6 px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Rankings
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {comparisonData.market_analysis.map((market, index) => (
                      <tr key={market.market_id} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                        <td className="w-1/6 px-6 py-4 whitespace-nowrap">
                          <div>
                            <div className="text-sm font-medium text-gray-900">{market.market_name}</div>
                            <div className="text-sm text-gray-500">{market.region_name}</div>
                            <div className="text-xs text-blue-600">{formatDate(market.last_updated)}</div>
                          </div>
                        </td>
                        <td className="w-1/6 px-6 py-4 whitespace-nowrap">
                          <div className="text-sm font-medium text-gray-900">
                            {formatPrice(market.latest_buy_price)}
                          </div>
                          <div className="text-xs text-gray-500">
                            Avg: {formatPrice(market.avg_buy_price)}
                          </div>
                        </td>
                        <td className="w-1/6 px-6 py-4 whitespace-nowrap">
                          <div className="text-sm font-medium text-gray-900">
                            {formatPrice(market.latest_sell_price)}
                          </div>
                          <div className="text-xs text-gray-500">
                            Avg: {formatPrice(market.avg_sell_price)}
                          </div>
                        </td>
                        <td className="w-1/6 px-6 py-4 whitespace-nowrap">
                          <div className="text-sm font-medium text-green-600">
                            {formatPrice(market.profit_margin)}
                          </div>
                          <div className="text-xs text-gray-500">
                            Range: {formatPrice(market.price_range)}
                          </div>
                        </td>
                        <td className="w-1/6 px-6 py-4 whitespace-nowrap">
                          <span className={`text-sm font-medium ${getVolatilityColor(market.volatility)}`}>
                            {market.volatility}
                          </span>
                          <div className="text-xs text-gray-500">
                            {market.data_points} data points
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex flex-col space-y-1">
                            <div>{getRankBadge(market.buy_rank, 'buy')}</div>
                            <div>{getRankBadge(market.sell_rank, 'sell')}</div>
                            <div>{getRankBadge(market.profit_rank, 'profit')}</div>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Additional Info */}
          <div className="bg-gray-50 rounded-lg p-4">
            <div className="flex flex-wrap items-center justify-between text-sm text-gray-600">
              <span>📅 Data from {formatDate(comparisonData.date_range.start)} to {formatDate(comparisonData.date_range.end)}</span>
              <span>🔄 Prices per {priceUnit}</span>
              <span>📊 {comparisonData.markets_compared} markets compared</span>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
