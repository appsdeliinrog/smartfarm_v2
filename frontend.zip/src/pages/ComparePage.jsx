import { MarketComparison } from '../components/MarketComparison';

export function ComparePage({ priceUnit }) {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-gray-900 mb-4">Market Comparison</h1>
        <p className="text-lg text-gray-600 mb-8">
          Compare prices across multiple markets side-by-side to identify the best trading opportunities.
        </p>
      </div>

      <MarketComparison priceUnit={priceUnit} />

      {/* Usage Tips */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-blue-800 mb-3">💡 How to Use Market Comparison</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-blue-700">
          <div>
            <h4 className="font-medium mb-2">For Maximum Profit:</h4>
            <ul className="space-y-1">
              <li>• Compare markets in your accessible region</li>
              <li>• Look for #1 rankings in buy/sell categories</li>
              <li>• Consider transport costs and distances</li>
              <li>• Check data freshness (last updated dates)</li>
            </ul>
          </div>
          <div>
            <h4 className="font-medium mb-2">Understanding Rankings:</h4>
            <ul className="space-y-1">
              <li>• <span className="bg-green-100 text-green-800 px-2 py-1 rounded text-xs">#1 Best Buy</span> = Cheapest to purchase</li>
              <li>• <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs">#1 Best Sell</span> = Highest selling price</li>
              <li>• <span className="bg-purple-100 text-purple-800 px-2 py-1 rounded text-xs">#1 Most Profitable</span> = Best local profit margin</li>
              <li>• Low volatility = More predictable prices</li>
            </ul>
          </div>
        </div>
        <div className="mt-4 text-xs text-blue-600">
          <strong>Pro Tip:</strong> The best arbitrage opportunities are usually between markets with #1 Best Buy and #1 Best Sell rankings.
        </div>
      </div>
    </div>
  );
}
