import { BestPriceFinder } from '../components/BestPriceFinder';

export function BestPricesPage({ priceUnit }) {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-gray-900 mb-4">Best Price Finder</h1>
        <p className="text-lg text-gray-600 mb-8">
          Discover the most profitable markets for buying and selling your commodities across Tanzania. 
          Our intelligent analysis identifies arbitrage opportunities and helps maximize your trading profits.
        </p>
      </div>

      <BestPriceFinder priceUnit={priceUnit} />

      {/* Additional market intelligence info */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-blue-800 mb-3">💡 How to Use This Tool</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-blue-700">
          <div>
            <h4 className="font-medium mb-2">For Farmers & Sellers:</h4>
            <ul className="space-y-1">
              <li>• Find markets offering the highest prices for your crops</li>
              <li>• Compare prices across different regions</li>
              <li>• Identify the best timing for sales</li>
            </ul>
          </div>
          <div>
            <h4 className="font-medium mb-2">For Traders & Buyers:</h4>
            <ul className="space-y-1">
              <li>• Discover cheapest sources for bulk purchases</li>
              <li>• Calculate potential arbitrage profits</li>
              <li>• Plan efficient buying routes</li>
            </ul>
          </div>
        </div>
        <div className="mt-4 text-xs text-blue-600">
          <strong>Note:</strong> Prices shown are based on recent market data. Consider transportation costs, 
          fuel prices, and market conditions when making trading decisions.
        </div>
      </div>
    </div>
  );
}
