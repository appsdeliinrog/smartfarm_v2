import { PriceChart } from '../components/PriceChart';
import { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { api } from '../api';

export function ChartsPage({ priceUnit }) {
  const location = useLocation();
  const [commodities, setCommodities] = useState([]);
  const [selectedCommodity, setSelectedCommodity] = useState('');
  const [regions, setRegions] = useState([]);
  const [selectedRegion, setSelectedRegion] = useState('');
  const [markets, setMarkets] = useState([]);
  const [selectedMarket, setSelectedMarket] = useState('');
  const [allMarkets, setAllMarkets] = useState([]);
  const [days, setDays] = useState(30);
  const [chartType, setChartType] = useState('line');
  const [showComparison, setShowComparison] = useState(false);
  const [comparisonCommodity, setComparisonCommodity] = useState('');
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState(null);

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      try {
        const [commoditiesRes, regionsRes, marketsRes] = await Promise.all([
          api.getCommodities(),
          api.getRegions(),
          api.getMarkets(),
        ]);
        setCommodities(commoditiesRes.results || commoditiesRes);
        setRegions(regionsRes.results || regionsRes);
        const marketsData = marketsRes.results || marketsRes;
        setAllMarkets(marketsData);
        setMarkets(marketsData); // Initially show all markets
        
        // Check for URL parameters
        const urlParams = new URLSearchParams(location.search);
        const commodityParam = urlParams.get('commodity');
        
        // Set default or URL-specified commodity
        const commoditiesData = commoditiesRes.results || commoditiesRes;
        if (commodityParam && commoditiesData.some(c => c.id === parseInt(commodityParam))) {
          setSelectedCommodity(commodityParam);
        } else if (commoditiesData.length > 0) {
          setSelectedCommodity(commoditiesData[0].id);
        }
      } catch (error) {
        console.error('Error loading data:', error);
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, [location.search]);

  // Filter markets based on selected region
  useEffect(() => {
    if (selectedRegion) {
      const filteredMarkets = allMarkets.filter(market => 
        market.region === parseInt(selectedRegion)
      );
      setMarkets(filteredMarkets);
      // Reset market selection when region changes
      setSelectedMarket('');
    } else {
      setMarkets(allMarkets);
      setSelectedMarket('');
    }
  }, [selectedRegion, allMarkets]);

  useEffect(() => {
    const loadStats = async () => {
      if (!selectedCommodity) return;
      
      try {
        const params = {
          commodity: selectedCommodity,
          days: days,
        };
        
        if (selectedMarket) {
          // If specific market is selected, filter by market
          params.market = selectedMarket;
        } else if (selectedRegion) {
          // If only region is selected, filter by region
          params.market__region = selectedRegion;
        }

        const data = await api.getPriceTrends(params);
        
        if (data.length > 0) {
          const prices = data.map(item => {
            const avgPrice = (parseFloat(item.avg_min_price || 0) + parseFloat(item.avg_max_price || 0)) / 2;
            return isNaN(avgPrice) ? 0 : avgPrice;
          }).filter(price => price > 0);
          
          if (prices.length > 0) {
            const minPrice = Math.min(...prices);
            const maxPrice = Math.max(...prices);
            const avgPrice = prices.reduce((sum, p) => sum + p, 0) / prices.length;
            const firstPrice = prices[prices.length - 1];
            const lastPrice = prices[0];
            const priceChange = lastPrice - firstPrice;
            const priceChangePercent = firstPrice > 0 ? (priceChange / firstPrice) * 100 : 0;
            
            // Convert prices based on display unit
            const convertPrice = (price) => priceUnit === '100kg' ? price * 100 : price;
            
            setStats({
              minPrice: convertPrice(minPrice),
              maxPrice: convertPrice(maxPrice),
              avgPrice: convertPrice(avgPrice),
              priceChange: convertPrice(priceChange),
              priceChangePercent,
              dataPoints: data.length
            });
          } else {
            setStats(null);
          }
        } else {
          setStats(null);
        }
      } catch (error) {
        console.error('Error loading stats:', error);
        setStats(null);
      }
    };
    
    loadStats();
  }, [selectedCommodity, selectedRegion, selectedMarket, days, priceUnit]);

  const selectedCommodityName = commodities.find(c => c.id === parseInt(selectedCommodity))?.name || 'Select a commodity';
  const selectedRegionName = regions.find(r => r.id === parseInt(selectedRegion))?.name || 'All Regions';
  const selectedMarketName = markets.find(m => m.id === parseInt(selectedMarket))?.name || 'All Markets';

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-gray-900 mb-4">Advanced Price Analytics</h1>
        <p className="text-lg text-gray-600 mb-8">
          Comprehensive price analysis with advanced charting and comparison tools for informed trading decisions.
        </p>
      </div>

      {/* Quick Stats */}
      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-white rounded-lg shadow-sm p-4">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                  <span className="text-blue-600 text-sm font-medium">📊</span>
                </div>
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-900">Average Price</p>
                <p className="text-lg font-semibold text-blue-600">
                  {stats.avgPrice.toLocaleString(undefined, { maximumFractionDigits: 0 })} TZS
                </p>
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-sm p-4">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                  <span className="text-green-600 text-sm font-medium">📈</span>
                </div>
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-900">Price Change</p>
                <p className={`text-lg font-semibold ${stats.priceChangePercent >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {stats.priceChangePercent >= 0 ? '+' : ''}{stats.priceChangePercent.toFixed(1)}%
                </p>
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-sm p-4">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <div className="w-8 h-8 bg-orange-100 rounded-full flex items-center justify-center">
                  <span className="text-orange-600 text-sm font-medium">📏</span>
                </div>
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-900">Price Range</p>
                <p className="text-lg font-semibold text-orange-600">
                  {(stats.maxPrice - stats.minPrice).toLocaleString(undefined, { maximumFractionDigits: 0 })} TZS
                </p>
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-sm p-4">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                  <span className="text-purple-600 text-sm font-medium">🎯</span>
                </div>
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-900">Data Points</p>
                <p className="text-lg font-semibold text-purple-600">
                  {stats.dataPoints}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Enhanced Chart Controls */}
      <div className="bg-white rounded-lg shadow-sm p-6">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 lg:mb-0">Chart Configuration</h3>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <label className="text-sm font-medium text-gray-700">Chart Type:</label>
              <select
                value={chartType}
                onChange={(e) => setChartType(e.target.value)}
                className="px-3 py-1 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
              >
                <option value="line">Line Chart</option>
                <option value="area">Area Chart</option>
                <option value="bar">Bar Chart</option>
              </select>
            </div>
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="comparison"
                checked={showComparison}
                onChange={(e) => setShowComparison(e.target.checked)}
                className="rounded border-gray-300 text-green-600 focus:ring-green-500"
              />
              <label htmlFor="comparison" className="text-sm font-medium text-gray-700">
                Enable Comparison
              </label>
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-4 lg:grid-cols-5 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Primary Commodity
            </label>
            <select
              value={selectedCommodity}
              onChange={(e) => setSelectedCommodity(e.target.value)}
              className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
            >
              <option value="">Select commodity...</option>
              {commodities.map((commodity) => (
                <option key={commodity.id} value={commodity.id}>
                  {commodity.name}
                </option>
              ))}
            </select>
          </div>
          
          {showComparison && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Compare With
              </label>
              <select
                value={comparisonCommodity}
                onChange={(e) => setComparisonCommodity(e.target.value)}
                className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
              >
                <option value="">Select commodity...</option>
                {commodities.filter(c => c.id !== parseInt(selectedCommodity)).map((commodity) => (
                  <option key={commodity.id} value={commodity.id}>
                    {commodity.name}
                  </option>
                ))}
              </select>
            </div>
          )}
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Region Filter
            </label>
            <select
              value={selectedRegion}
              onChange={(e) => setSelectedRegion(e.target.value)}
              className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
            >
              <option value="">All Regions</option>
              {regions.map((region) => (
                <option key={region.id} value={region.id}>
                  {region.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Market Filter
            </label>
            <select
              value={selectedMarket}
              onChange={(e) => setSelectedMarket(e.target.value)}
              className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
              disabled={!selectedRegion}
            >
              <option value="">All Markets {selectedRegion ? `in ${selectedRegionName}` : ''}</option>
              {markets.map((market) => (
                <option key={market.id} value={market.id}>
                  {market.name}
                </option>
              ))}
            </select>
            {!selectedRegion && (
              <p className="text-xs text-gray-500 mt-1">
                Select a region first to filter by specific markets
              </p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Time Period
            </label>
            <select
              value={days}
              onChange={(e) => setDays(parseInt(e.target.value))}
              className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
            >
              <option value={7}>Last 7 days</option>
              <option value={14}>Last 2 weeks</option>
              <option value={30}>Last month</option>
              <option value={60}>Last 2 months</option>
              <option value={90}>Last 3 months</option>
              <option value={180}>Last 6 months</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Price Unit
            </label>
            <div className="bg-gray-100 rounded-md p-2">
              <span className="text-sm font-medium text-gray-700">
                per {priceUnit === 'kg' ? 'Kilogram' : '100 Kilograms'}
              </span>
            </div>
          </div>
        </div>
        
        {/* Selected filters summary */}
        <div className="mt-4 flex flex-wrap gap-2">
          <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
            📊 {selectedCommodityName}
          </span>
          <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
            🌍 {selectedRegionName}
          </span>
          {selectedMarket && (
            <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">
              🏪 {selectedMarketName}
            </span>
          )}
          <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
            📅 {days} days
          </span>
          {showComparison && comparisonCommodity && (
            <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-orange-100 text-orange-800">
              🔄 Comparing with {commodities.find(c => c.id === parseInt(comparisonCommodity))?.name}
            </span>
          )}
        </div>
      </div>

      {/* Price Charts */}
      {selectedCommodity ? (
        <div className="space-y-6">
          {/* Primary Chart */}
          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-medium text-gray-900">
                {selectedCommodityName} Price Trends
              </h3>
              <div className="flex items-center gap-2 text-sm text-gray-500">
                <span>📍 {selectedRegionName}</span>
                {selectedMarket && (
                  <>
                    <span>•</span>
                    <span>🏪 {selectedMarketName}</span>
                  </>
                )}
                <span>•</span>
                <span>📅 Last {days} days</span>
                <span>•</span>
                <span>💰 per {priceUnit}</span>
              </div>
            </div>
            <PriceChart 
              commodityId={selectedCommodity}
              marketId={selectedMarket || undefined}
              marketRegionId={selectedRegion || undefined}
              days={days}
              priceUnit={priceUnit}
              chartType={chartType}
            />
          </div>

          {/* Comparison Chart */}
          {showComparison && comparisonCommodity && (
            <div className="bg-white rounded-lg shadow-sm p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-medium text-gray-900">
                  Comparison: {commodities.find(c => c.id === parseInt(comparisonCommodity))?.name}
                </h3>
                <div className="flex items-center gap-2 text-sm text-gray-500">
                  <span>🔄 Comparison View</span>
                  <span>•</span>
                  <span>📍 {selectedRegionName}</span>
                  {selectedMarket && (
                    <>
                      <span>•</span>
                      <span>🏪 {selectedMarketName}</span>
                    </>
                  )}
                </div>
              </div>
              <PriceChart 
                commodityId={comparisonCommodity}
                marketId={selectedMarket || undefined}
                marketRegionId={selectedRegion || undefined}
                days={days}
                priceUnit={priceUnit}
                chartType={chartType}
              />
            </div>
          )}

          {/* Market Insights */}
          {stats && (
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Market Insights</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div className="bg-gradient-to-r from-blue-50 to-blue-100 rounded-lg p-4">
                  <h4 className="font-medium text-blue-900 mb-2">Price Stability</h4>
                  <p className="text-sm text-blue-700">
                    {Math.abs(stats.priceChangePercent) < 5 
                      ? '🟢 Stable - Low volatility detected' 
                      : Math.abs(stats.priceChangePercent) < 15 
                        ? '🟡 Moderate - Some price fluctuation' 
                        : '🔴 High volatility - Significant price changes'
                    }
                  </p>
                  <p className="text-xs text-blue-600 mt-1">
                    Volatility: {Math.abs(stats.priceChangePercent).toFixed(1)}%
                  </p>
                </div>
                
                <div className="bg-gradient-to-r from-green-50 to-green-100 rounded-lg p-4">
                  <h4 className="font-medium text-green-900 mb-2">Price Trend</h4>
                  <p className="text-sm text-green-700">
                    {stats.priceChangePercent > 2 
                      ? '📈 Upward trend - Prices rising' 
                      : stats.priceChangePercent < -2 
                        ? '📉 Downward trend - Prices falling' 
                        : '➡️ Sideways - Prices stable'
                    }
                  </p>
                  <p className="text-xs text-green-600 mt-1">
                    Change: {stats.priceChangePercent >= 0 ? '+' : ''}{stats.priceChangePercent.toFixed(1)}%
                  </p>
                </div>
                
                <div className="bg-gradient-to-r from-purple-50 to-purple-100 rounded-lg p-4">
                  <h4 className="font-medium text-purple-900 mb-2">Data Quality</h4>
                  <p className="text-sm text-purple-700">
                    {stats.dataPoints >= 20 
                      ? '✅ Excellent - Rich data available' 
                      : stats.dataPoints >= 10 
                        ? '✅ Good - Sufficient data points' 
                        : '⚠️ Limited - Few data points available'
                    }
                  </p>
                  <p className="text-xs text-purple-600 mt-1">
                    {stats.dataPoints} observations
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      ) : (
        <div className="bg-white rounded-lg shadow-sm p-12 text-center">
          <div className="max-w-md mx-auto">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-2xl">📊</span>
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">Select a Commodity</h3>
            <p className="text-gray-600">
              Choose a commodity from the dropdown above to view detailed price trends and analysis.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
