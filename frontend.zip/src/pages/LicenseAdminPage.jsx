import { LicenseAdmin } from '../components/LicenseAdmin';

export function LicenseAdminPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900 mb-2">
          License Administration
        </h1>
        <p className="text-gray-600">
          Manage licensing and watermark settings for the Tanzania Crop Price Monitoring System.
        </p>
      </div>
      
      <LicenseAdmin />
      
      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
        <h3 className="text-lg font-semibold text-yellow-800 mb-2">
          ⚠️ Developer Note
        </h3>
        <p className="text-yellow-700 text-sm">
          This page is for development and testing purposes. In production, 
          license management should be handled through secure channels and 
          this page should be removed or access-controlled.
        </p>
      </div>
    </div>
  );
}
