import { useState } from 'react';
import { Dashboard } from '../components/Dashboard';
import { PriceChart } from '../components/PriceChart';
import { FilterBar } from '../components/FilterBar';
import { PriceGrid } from '../components/PriceGrid';
import { SmartAlerts } from '../components/SmartAlerts';
import { PredictionsPanel } from '../components/PredictionsPanel';

export function DashboardPage({ priceUnit }) {
  const [filters, setFilters] = useState({ days: '30' });  // Initialize with default days
  const [showPredictions, setShowPredictions] = useState(true);

  return (
    <div className="space-y-8">
      {/* Smart Alerts Section */}
      <div>
        <SmartAlerts priceUnit={priceUnit} />
      </div>

      {/* Dashboard Stats */}
      <div>
        <h2 className="text-xl font-semibold text-gray-900 mb-4">
          Market Overview
        </h2>
        <Dashboard priceUnit={priceUnit} />
      </div>

      {/* Price Chart and Predictions */}
      {filters.commodity ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold text-gray-900">
                Price Trends
              </h2>
              <div className="flex items-center space-x-4">
                <label className="flex items-center space-x-2 text-sm bg-purple-50 px-3 py-2 rounded-lg border border-purple-200 hover:bg-purple-100 transition-colors cursor-pointer">
                  <input
                    type="checkbox"
                    checked={showPredictions}
                    onChange={(e) => setShowPredictions(e.target.checked)}
                    className="rounded border-gray-300 text-purple-600 focus:ring-purple-500"
                  />
                  <span className="font-medium text-purple-700">Show AI Predictions</span>
                  <span className="text-xs text-purple-600 bg-purple-200 px-2 py-0.5 rounded-full">BETA</span>
                </label>
              </div>
            </div>
            <PriceChart 
              commodityId={filters.commodity}
              marketId={filters.market}
              marketRegionId={filters.market__region}
              days={filters.days || 30}
              priceUnit={priceUnit}
              showPredictions={showPredictions}
            />
          </div>
          
          <div>
            <PredictionsPanel 
              commodityId={filters.commodity}
              marketId={filters.market}
              priceUnit={priceUnit}
            />
          </div>
        </div>
      ) : (
        <div className="bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg border border-purple-200 p-8 text-center">
          <div className="max-w-md mx-auto">
            <div className="text-purple-600 mb-4">
              <svg className="w-16 h-16 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
              </svg>
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              Select a Commodity for AI Predictions
            </h3>
            <p className="text-gray-600 mb-4">
              Choose a commodity from the filters above to view price trends and AI-powered forecasting with confidence intervals.
            </p>
            <div className="bg-white rounded-lg p-4 shadow-sm">
              <h4 className="font-medium text-purple-700 mb-2">🔮 AI Prediction Features:</h4>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• 14-day price forecasts</li>
                <li>• Confidence intervals & accuracy scores</li>
                <li>• Seasonal pattern analysis</li>
                <li>• Trend direction predictions</li>
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* Filters and Price Grid */}
      <div>
        <FilterBar onFilterChange={setFilters} filters={filters} />
        
        <div className="mb-6 mt-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-2">
            Latest Prices
          </h2>
          <p className="text-gray-600">
            Current wholesale prices from markets across Tanzania (per {priceUnit})
          </p>
        </div>

        <PriceGrid filters={filters} priceUnit={priceUnit} />
      </div>
    </div>
  );
}
