import React, { useState } from 'react';
import PriceHeatMap from '../components/PriceHeatMap';
import VolatilityDashboard from '../components/VolatilityDashboard';

export const VisualAnalyticsPage = ({ priceUnit }) => {
  const [activeTab, setActiveTab] = useState('heatmap');

  const tabs = [
    {
      id: 'heatmap',
      name: 'Regional Heat Map',
      icon: '🗺️',
      description: 'Visual comparison of prices across regions'
    },
    {
      id: 'volatility',
      name: 'Volatility Analysis',
      icon: '📊',
      description: 'Market risk and price stability monitoring'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-blue-100 rounded-lg">
            <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
            </svg>
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Visual Analytics</h1>
            <p className="text-gray-600 mt-1">
              Advanced data visualization and market intelligence tools
            </p>
          </div>
        </div>
      </div>

      {/* Analytics Features Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center gap-3 mb-3">
            <div className="p-2 bg-purple-100 rounded-lg">
              <span className="text-xl">🗺️</span>
            </div>
            <h3 className="font-semibold text-gray-900">Regional Heat Maps</h3>
          </div>
          <p className="text-sm text-gray-600 mb-3">
            Color-coded visualization of price levels across different regions for quick market comparison.
          </p>
          <ul className="text-sm text-gray-600 space-y-1">
            <li>• Interactive regional price comparison</li>
            <li>• Heat intensity based on price levels</li>
            <li>• Market count and price range analysis</li>
          </ul>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center gap-3 mb-3">
            <div className="p-2 bg-orange-100 rounded-lg">
              <span className="text-xl">📊</span>
            </div>
            <h3 className="font-semibold text-gray-900">Volatility Analysis</h3>
          </div>
          <p className="text-sm text-gray-600 mb-3">
            Risk assessment and price stability monitoring to identify market opportunities and threats.
          </p>
          <ul className="text-sm text-gray-600 space-y-1">
            <li>• Price volatility calculations</li>
            <li>• Risk level categorization</li>
            <li>• Market stability rankings</li>
          </ul>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6" aria-label="Tabs">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-4 px-1 border-b-2 font-medium text-sm whitespace-nowrap ${
                  activeTab === tab.id
                    ? 'border-green-500 text-green-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span className="text-lg">{tab.icon}</span>
                  <span>{tab.name}</span>
                </div>
              </button>
            ))}
          </nav>
        </div>

        {/* Tab Content */}
        <div className="p-6">
          {activeTab === 'heatmap' && (
            <div>
              <div className="mb-4">
                <h3 className="text-lg font-medium text-gray-900">Regional Price Heat Map</h3>
                <p className="text-sm text-gray-600">
                  Interactive visualization showing price levels across different regions with color intensity
                </p>
              </div>
              <PriceHeatMap priceUnit={priceUnit} />
            </div>
          )}

          {activeTab === 'volatility' && (
            <div>
              <div className="mb-4">
                <h3 className="text-lg font-medium text-gray-900">Market Volatility Analysis</h3>
                <p className="text-sm text-gray-600">
                  Comprehensive risk assessment showing price stability and market volatility metrics
                </p>
              </div>
              <VolatilityDashboard priceUnit={priceUnit} />
            </div>
          )}
        </div>
      </div>

      {/* Current Price Unit Info */}
      <div className="bg-green-50 border border-green-200 rounded-lg p-4">
        <div className="flex items-center gap-2">
          <svg className="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          <span className="text-sm font-medium text-green-900">
            All visualizations are showing prices per {priceUnit === 'kg' ? 'kilogram' : '100 kilograms'}
          </span>
        </div>
        <p className="text-sm text-green-700 mt-1 ml-7">
          Use the price unit toggle in the navigation to switch between kg and 100kg pricing
        </p>
      </div>
    </div>
  );
};

export default VisualAnalyticsPage;
