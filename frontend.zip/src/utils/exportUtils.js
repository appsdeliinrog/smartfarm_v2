import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import html2canvas from 'html2canvas';
import { saveAs } from 'file-saver';

// Ensure autoTable is properly attached to jsPDF
if (typeof jsPDF.prototype.autoTable !== 'function' && typeof autoTable === 'function') {
  jsPDF.prototype.autoTable = function(options) {
    return autoTable(this, options);
  };
}

// Export comparison data as PDF report
export const exportToPDF = async (comparisonData, selectedCommodity, commodityName, priceUnit) => {
  const pdf = new jsPDF();
  
  // Ensure autoTable is available on this instance
  if (typeof pdf.autoTable !== 'function' && typeof autoTable === 'function') {
    pdf.autoTable = function(options) {
      return autoTable(this, options);
    };
  }
  
  // Check if autoTable is available for enhanced formatting
  if (typeof pdf.autoTable !== 'function') {
    console.warn('❌ autoTable not available, using basic PDF format');
    return await exportBasicPDF(pdf, comparisonData, commodityName, priceUnit);
  }
  
  console.log('✅ Using enhanced PDF format with autoTable and charts');
  
  const pageWidth = pdf.internal.pageSize.getWidth();
  const pageHeight = pdf.internal.pageSize.getHeight();
  
  // Helper function to format currency
  const formatCurrency = (value) => {
    if (!value) return 'N/A';
    return new Intl.NumberFormat('en-TZ', {
      style: 'currency',
      currency: 'TZS',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };
  
  // Header
  pdf.setFontSize(20);
  pdf.setTextColor(34, 197, 94); // Green color
  pdf.text('Tanzania Crop Price Analysis Report', 20, 25);
  
  // Subtitle
  pdf.setFontSize(14);
  pdf.setTextColor(0, 0, 0);
  pdf.text(`Commodity: ${commodityName}`, 20, 40);
  pdf.text(`Generated: ${new Date().toLocaleDateString()}`, 20, 50);
  pdf.text(`Price Unit: ${priceUnit}`, 20, 60);
  
  let yPosition = 80;
  
  // Executive Summary
  pdf.setFontSize(16);
  pdf.setTextColor(51, 51, 51);
  pdf.text('EXECUTIVE SUMMARY', 20, yPosition);
  yPosition += 15;
  
  if (comparisonData.summary) {
    // Summary table
    const summaryData = [
      ['Markets Analyzed', comparisonData.markets_compared || 'N/A'],
      ['Best Buy Market', comparisonData.summary.best_buy_market || 'N/A'],
      ['Best Buy Price', comparisonData.summary.best_buy_price ? formatCurrency(comparisonData.summary.best_buy_price) : 'N/A'],
      ['Best Sell Market', comparisonData.summary.best_sell_market || 'N/A'],
      ['Best Sell Price', comparisonData.summary.best_sell_price ? formatCurrency(comparisonData.summary.best_sell_price) : 'N/A'],
      ['Max Profit Potential', comparisonData.summary.max_arbitrage ? formatCurrency(comparisonData.summary.max_arbitrage) : 'N/A']
    ];
    
    pdf.autoTable({
      startY: yPosition,
      head: [['Metric', 'Value']],
      body: summaryData,
      theme: 'grid',
      headStyles: { fillColor: [34, 197, 94], textColor: 255 },
      styles: { fontSize: 10 },
      columnStyles: {
        0: { fontStyle: 'bold', cellWidth: 60 },
        1: { cellWidth: 80 }
      },
      margin: { left: 20, right: 20 }
    });
    
    yPosition = pdf.lastAutoTable.finalY + 20;
  }
  
  // Market Analysis Table
  if (yPosition > 200) {
    pdf.addPage();
    yPosition = 30;
  }
  
  pdf.setFontSize(16);
  pdf.setTextColor(51, 51, 51);
  pdf.text('DETAILED MARKET ANALYSIS', 20, yPosition);
  yPosition += 15;
  
  if (comparisonData.market_analysis && comparisonData.market_analysis.length > 0) {
    const tableData = comparisonData.market_analysis.map((market, index) => [
      `${market.market_name}\n(${market.region_name})`,
      formatCurrency(market.latest_buy_price),
      formatCurrency(market.latest_sell_price),
      formatCurrency(market.profit_margin),
      market.volatility || 'N/A',
      `Buy: #${market.buy_rank || 'N/A'}\nSell: #${market.sell_rank || 'N/A'}\nProfit: #${market.profit_rank || 'N/A'}`
    ]);
    
    pdf.autoTable({
      startY: yPosition,
      head: [['Market', 'Buy Price', 'Sell Price', 'Profit Margin', 'Volatility', 'Rankings']],
      body: tableData,
      theme: 'striped',
      headStyles: { 
        fillColor: [59, 130, 246], 
        textColor: 255,
        fontSize: 10,
        fontStyle: 'bold'
      },
      bodyStyles: { fontSize: 9 },
      columnStyles: {
        0: { cellWidth: 30 }, // Market - reduced from 35
        1: { cellWidth: 22 }, // Buy Price - reduced from 25
        2: { cellWidth: 22 }, // Sell Price - reduced from 25
        3: { cellWidth: 22 }, // Profit Margin - reduced from 25
        4: { cellWidth: 18 }, // Volatility - reduced from 20
        5: { cellWidth: 25 }  // Rankings - reduced from 30
      },
      styles: {
        overflow: 'linebreak',
        cellPadding: 3
      },
      margin: { left: 20, right: 20 }
    });
    
    yPosition = pdf.lastAutoTable.finalY + 20;
  }
  
  // Add charts section before trading recommendations
  // Check if we need a new page for charts
  if (yPosition > 200) {
    pdf.addPage();
    yPosition = 30;
  }
  
  pdf.setFontSize(16);
  pdf.setTextColor(51, 51, 51);
  pdf.text('MARKET ANALYSIS CHARTS', 20, yPosition);
  yPosition += 15;
  
  // Function to add chart to PDF
  const addChartToPDF = async (chartId, title, yPos) => {
    const chartElement = document.getElementById(chartId);
    if (chartElement) {
      try {
        const canvas = await html2canvas(chartElement, {
          backgroundColor: '#ffffff',
          scale: 2,
          useCORS: true
        });
        const imgData = canvas.toDataURL('image/png');
        const imgWidth = 170;
        const imgHeight = (canvas.height * imgWidth) / canvas.width;
        
        // Add chart title
        pdf.setFontSize(12);
        pdf.setTextColor(0, 0, 0);
        pdf.text(title, 20, yPos);
        
        // Add the chart image
        pdf.addImage(imgData, 'PNG', 20, yPos + 10, imgWidth, imgHeight);
        
        return yPos + imgHeight + 20;
      } catch (error) {
        console.warn(`Could not capture chart ${chartId}:`, error);
        return yPos + 20;
      }
    }
    return yPos;
  };
  
  // Try to add charts if they exist (common chart IDs used in the app)
  const chartIds = ['price-comparison-chart', 'market-trend-chart', 'price-chart'];
  
  for (const chartId of chartIds) {
    const chartElement = document.getElementById(chartId);
    if (chartElement) {
      console.log(`📊 Adding chart ${chartId} to PDF`);
      yPosition = await addChartToPDF(chartId, 'Market Price Comparison', yPosition);
      
      // Check if we need a new page for trading recommendations
      if (yPosition > 220) {
        pdf.addPage();
        yPosition = 30;
      }
      break; // Add only the first chart found
    }
  }
  
  // Trading Recommendations
  if (yPosition > 220) {
    pdf.addPage();
    yPosition = 30;
  }
  
  pdf.setFontSize(16);
  pdf.setTextColor(51, 51, 51);
  pdf.text('TRADING RECOMMENDATIONS', 20, yPosition);
  yPosition += 15;
  
  const recommendations = [];
  
  if (comparisonData.summary?.max_arbitrage > 0) {
    recommendations.push(['ARBITRAGE OPPORTUNITY', 'DETECTED']);
    recommendations.push(['Buy from', comparisonData.summary.best_buy_market]);
    recommendations.push(['Sell to', comparisonData.summary.best_sell_market]);
    recommendations.push(['Expected Profit', formatCurrency(comparisonData.summary.max_arbitrage) + ` per ${priceUnit}`]);
    recommendations.push(['', '']); // Spacer
  }
  
  recommendations.push(
    ['General Advice', 'Monitor price fluctuations regularly'],
    ['Cost Consideration', 'Include transportation costs in calculations'],
    ['Risk Management', 'Verify market conditions before trading'],
    ['Strategy', 'Focus on low volatility markets for stability']
  );
  
  pdf.autoTable({
    startY: yPosition,
    body: recommendations,
    theme: 'plain',
    styles: { 
      fontSize: 10,
      cellPadding: 4
    },
    columnStyles: {
      0: { fontStyle: 'bold', cellWidth: 40 },
      1: { cellWidth: 100 }
    },
    margin: { left: 20, right: 20 }
  });
  
  // Footer on all pages
  const totalPages = pdf.internal.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    pdf.setPage(i);
    pdf.setFontSize(8);
    pdf.setTextColor(128, 128, 128);
    pdf.text(`Page ${i} of ${totalPages} - Generated by AgriPrice Monitor`, 20, pageHeight - 10);
  }
  
  // Save the PDF
  const pdfFileName = `market-analysis-${commodityName.toLowerCase().replace(/\s+/g, '-')}-${new Date().toISOString().split('T')[0]}.pdf`;
  pdf.save(pdfFileName);
  
  return true;
  
};

// Helper function to format prices for PDF
const formatPriceForPDF = (price, priceUnit) => {
  if (!price) return 'N/A';
  const convertedPrice = priceUnit === '100kg' ? price * 100 : price;
  return new Intl.NumberFormat('en-TZ', {
    style: 'currency',
    currency: 'TZS',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(convertedPrice);
};

// Export comparison data as CSV
export const exportToCSV = (comparisonData, commodityName, priceUnit) => {
  const headers = [
    'Market Name',
    'Region',
    `Buy Price (${priceUnit})`,
    `Sell Price (${priceUnit})`,
    `Profit Margin (${priceUnit})`,
    'Volatility',
    'Buy Rank',
    'Sell Rank', 
    'Profit Rank',
    'Last Updated',
    'Data Points'
  ];
  
  const rows = comparisonData.market_analysis.map(market => [
    market.market_name,
    market.region_name,
    market.latest_buy_price || 'N/A',
    market.latest_sell_price || 'N/A',
    market.profit_margin || 'N/A',
    market.volatility,
    market.buy_rank,
    market.sell_rank,
    market.profit_rank,
    market.last_updated || 'N/A',
    market.data_points
  ]);
  
  const csvContent = [headers, ...rows]
    .map(row => row.map(field => `"${field}"`).join(','))
    .join('\n');
  
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const csvFileName = `market-comparison-${commodityName.toLowerCase().replace(/\s+/g, '-')}-${new Date().toISOString().split('T')[0]}.csv`;
  saveAs(blob, csvFileName);
};

// Export chart as image
export const exportChartAsImage = async (chartElementId, fileName) => {
  const chartElement = document.getElementById(chartElementId);
  if (!chartElement) {
    console.error('Chart element not found');
    return;
  }
  
  try {
    const canvas = await html2canvas(chartElement, {
      backgroundColor: '#ffffff',
      scale: 2, // Higher quality
      logging: false
    });
    
    canvas.toBlob((blob) => {
      saveAs(blob, `${fileName}-${new Date().toISOString().split('T')[0]}.png`);
    });
  } catch (error) {
    console.error('Error exporting chart:', error);
  }
};

// Save comparison to localStorage (favorites)
export const saveComparison = (comparisonData, commodityName, selectedMarkets, selectedCommodity) => {
  const savedComparisons = JSON.parse(localStorage.getItem('savedComparisons') || '[]');
  
  const newComparison = {
    id: Date.now(),
    name: `${commodityName} - ${selectedMarkets.length} markets`,
    commodityName,
    selectedCommodity,
    selectedMarkets,
    summary: comparisonData.summary,
    savedAt: new Date().toISOString(),
    marketsCount: comparisonData.markets_compared
  };
  
  savedComparisons.unshift(newComparison);
  
  // Keep only last 10 comparisons
  if (savedComparisons.length > 10) {
    savedComparisons.splice(10);
  }
  
  localStorage.setItem('savedComparisons', JSON.stringify(savedComparisons));
  return newComparison;
};

// Load saved comparisons
export const getSavedComparisons = () => {
  return JSON.parse(localStorage.getItem('savedComparisons') || '[]');
};

// Delete saved comparison
export const deleteSavedComparison = (comparisonId) => {
  const savedComparisons = JSON.parse(localStorage.getItem('savedComparisons') || '[]');
  const filtered = savedComparisons.filter(comp => comp.id !== comparisonId);
  localStorage.setItem('savedComparisons', JSON.stringify(filtered));
  return filtered;
};

// Fallback PDF export without autoTable
const exportBasicPDF = async (pdf, comparisonData, commodityName, priceUnit) => {
  const pageWidth = pdf.internal.pageSize.getWidth();
  
  // Helper function to format currency
  const formatCurrency = (value) => {
    if (!value) return 'N/A';
    return new Intl.NumberFormat('en-TZ', {
      style: 'currency',
      currency: 'TZS',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };
  
  // Function to add chart to PDF
  const addChartToPDF = async (chartId, title, yPos) => {
    const chartElement = document.getElementById(chartId);
    if (chartElement) {
      try {
        const canvas = await html2canvas(chartElement, {
          backgroundColor: '#ffffff',
          scale: 1,
          logging: false,
          width: 400,
          height: 300
        });
        
        const imgData = canvas.toDataURL('image/png');
        pdf.setFontSize(12);
        pdf.setTextColor(51, 51, 51);
        pdf.text(title, 20, yPos);
        pdf.addImage(imgData, 'PNG', 20, yPos + 5, 160, 80); // Scaled to fit
        return yPos + 90; // Return new Y position
      } catch (error) {
        console.warn(`Could not capture chart ${chartId}:`, error);
        return yPos;
      }
    }
    return yPos;
  };
  
  // Header
  pdf.setFontSize(20);
  pdf.setTextColor(34, 197, 94); // Green color
  pdf.text('Tanzania Crop Price Analysis Report', 20, 25);
  
  // Subtitle
  pdf.setFontSize(14);
  pdf.setTextColor(0, 0, 0);
  pdf.text(`Commodity: ${commodityName}`, 20, 40);
  pdf.text(`Generated: ${new Date().toLocaleDateString()}`, 20, 50);
  pdf.text(`Price Unit: ${priceUnit}`, 20, 60);
  
  // Summary section
  pdf.setFontSize(16);
  pdf.setTextColor(51, 51, 51);
  pdf.text('EXECUTIVE SUMMARY', 20, 80);
  
  let yPosition = 95;
  pdf.setFontSize(12);
  pdf.setTextColor(0, 0, 0);
  
  if (comparisonData.summary) {
    pdf.text(`Markets Analyzed: ${comparisonData.markets_compared || 'N/A'}`, 20, yPosition);
    yPosition += 12;
    
    if (comparisonData.summary.best_buy_market) {
      pdf.setTextColor(34, 197, 94); // Green for best buy
      pdf.text(`BEST BUY OPPORTUNITY:`, 20, yPosition);
      yPosition += 10;
      pdf.setTextColor(0, 0, 0);
      pdf.text(`   Market: ${comparisonData.summary.best_buy_market}`, 20, yPosition);
      yPosition += 8;
      pdf.text(`   Price: ${formatCurrency(comparisonData.summary.best_buy_price)} per ${priceUnit}`, 20, yPosition);
      yPosition += 15;
    }
    
    if (comparisonData.summary.best_sell_market) {
      pdf.setTextColor(59, 130, 246); // Blue for best sell
      pdf.text(`BEST SELL OPPORTUNITY:`, 20, yPosition);
      yPosition += 10;
      pdf.setTextColor(0, 0, 0);
      pdf.text(`   Market: ${comparisonData.summary.best_sell_market}`, 20, yPosition);
      yPosition += 8;
      pdf.text(`   Price: ${formatCurrency(comparisonData.summary.best_sell_price)} per ${priceUnit}`, 20, yPosition);
      yPosition += 15;
    }
    
    if (comparisonData.summary.max_arbitrage) {
      pdf.setFontSize(14);
      pdf.setTextColor(255, 140, 0); // Orange for profit highlight
      pdf.text(`MAXIMUM PROFIT POTENTIAL:`, 20, yPosition);
      yPosition += 12;
      pdf.setFontSize(16);
      pdf.setTextColor(255, 69, 0); // Red-orange for emphasis
      pdf.text(`${formatCurrency(comparisonData.summary.max_arbitrage)} per ${priceUnit}`, 30, yPosition);
      yPosition += 20;
    }
  }
  
  // Charts section
  if (yPosition > 200) {
    pdf.addPage();
    yPosition = 30;
  }
  
  pdf.setFontSize(16);
  pdf.setTextColor(51, 51, 51);
  pdf.text('MARKET ANALYSIS CHARTS', 20, yPosition);
  yPosition += 15;
  
  // Try to add charts if they exist
  try {
    yPosition = await addChartToPDF('price-comparison-chart', 'Price Comparison Chart', yPosition);
    yPosition += 10;
    
    if (yPosition > 200) {
      pdf.addPage();
      yPosition = 30;
    }
    
    yPosition = await addChartToPDF('profit-margin-chart', 'Profit Margin Analysis', yPosition);
    yPosition += 10;
    
    if (yPosition > 200) {
      pdf.addPage();
      yPosition = 30;
    }
    
    yPosition = await addChartToPDF('volatility-chart', 'Market Volatility', yPosition);
    yPosition += 20;
  } catch (error) {
    console.warn('Could not add charts to PDF:', error);
    pdf.setFontSize(12);
    pdf.setTextColor(128, 128, 128);
    pdf.text('Charts could not be captured. Please check the Market Comparison page.', 20, yPosition);
    yPosition += 20;
  }
  
  // Market details section
  if (yPosition > 220) {
    pdf.addPage();
    yPosition = 30;
  }
  
  pdf.setFontSize(16);
  pdf.setTextColor(51, 51, 51);
  pdf.text('DETAILED MARKET ANALYSIS', 20, yPosition);
  yPosition += 15;
  pdf.setFontSize(12);
  pdf.setTextColor(0, 0, 0);
  
  if (comparisonData.market_analysis) {
    comparisonData.market_analysis.forEach((market, index) => {
      if (yPosition > 250) { // New page if needed
        pdf.addPage();
        pdf.setFontSize(16);
        pdf.setTextColor(51, 51, 51);
        pdf.text('DETAILED MARKET ANALYSIS (continued)', 20, 30);
        yPosition = 50;
        pdf.setFontSize(12);
        pdf.setTextColor(0, 0, 0);
      }
      
      // Market name with ranking badge
      pdf.setFontSize(13);
      pdf.setTextColor(51, 51, 51);
      pdf.text(`${index + 1}. ${market.market_name}`, 20, yPosition);
      pdf.setFontSize(11);
      pdf.setTextColor(128, 128, 128);
      pdf.text(`(${market.region_name})`, 120, yPosition);
      yPosition += 12;
      
      // Price information
      pdf.setFontSize(10);
      pdf.setTextColor(34, 197, 94); // Green for buy
      pdf.text(`Buy Price: ${formatCurrency(market.latest_buy_price)}`, 25, yPosition);
      pdf.setTextColor(59, 130, 246); // Blue for sell
      pdf.text(`Sell Price: ${formatCurrency(market.latest_sell_price)}`, 110, yPosition);
      yPosition += 10;
      
      // Profit and volatility
      pdf.setTextColor(255, 140, 0); // Orange for profit
      pdf.text(`Profit Margin: ${formatCurrency(market.profit_margin)}`, 25, yPosition);
      
      // Volatility with color coding
      const volatilityColor = market.volatility === 'Low' ? [34, 197, 94] : 
                             market.volatility === 'Medium' ? [255, 140, 0] : [239, 68, 68];
      pdf.setTextColor(...volatilityColor);
      pdf.text(`Volatility: ${market.volatility || 'N/A'}`, 110, yPosition);
      yPosition += 10;
      
      // Rankings if available
      if (market.buy_rank || market.sell_rank || market.profit_rank) {
        pdf.setFontSize(9);
        pdf.setTextColor(128, 128, 128);
        let rankings = [];
        if (market.buy_rank) rankings.push(`Buy Rank: #${market.buy_rank}`);
        if (market.sell_rank) rankings.push(`Sell Rank: #${market.sell_rank}`);
        if (market.profit_rank) rankings.push(`Profit Rank: #${market.profit_rank}`);
        pdf.text(`   ${rankings.join(' | ')}`, 25, yPosition);
        yPosition += 8;
      }
      
      yPosition += 8; // Extra spacing between markets
    });
  }
  
  // Trading Recommendations Section
  if (yPosition > 220) { // New page if needed
    pdf.addPage();
    yPosition = 30;
  } else {
    yPosition += 20;
  }
  
  pdf.setFontSize(16);
  pdf.setTextColor(51, 51, 51);
  pdf.text('TRADING RECOMMENDATIONS', 20, yPosition);
  yPosition += 15;
  
  pdf.setFontSize(12);
  pdf.setTextColor(0, 0, 0);
  
  if (comparisonData.summary?.max_arbitrage > 0) {
    pdf.setTextColor(34, 197, 94);
    pdf.text('ARBITRAGE OPPORTUNITY DETECTED:', 20, yPosition);
    yPosition += 12;
    pdf.setTextColor(0, 0, 0);
    pdf.text(`- Buy from: ${comparisonData.summary.best_buy_market}`, 25, yPosition);
    yPosition += 10;
    pdf.text(`- Sell to: ${comparisonData.summary.best_sell_market}`, 25, yPosition);
    yPosition += 10;
    pdf.text(`- Expected profit: ${formatCurrency(comparisonData.summary.max_arbitrage)} per ${priceUnit}`, 25, yPosition);
    yPosition += 15;
  }
  
  pdf.text('GENERAL RECOMMENDATIONS:', 20, yPosition);
  yPosition += 12;
  pdf.text('- Monitor price fluctuations regularly for optimal timing', 25, yPosition);
  yPosition += 10;
  pdf.text('- Consider transportation costs in profit calculations', 25, yPosition);
  yPosition += 10;
  pdf.text('- Verify market conditions before executing trades', 25, yPosition);
  yPosition += 10;
  pdf.text('- Focus on markets with low volatility for stable returns', 25, yPosition);
  yPosition += 15;
  
  // Footer
  const totalPages = pdf.internal.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    pdf.setPage(i);
    pdf.setFontSize(8);
    pdf.setTextColor(128, 128, 128);
    pdf.text(`Page ${i} of ${totalPages} - Generated by AgriPrice Monitor`, 20, pdf.internal.pageSize.getHeight() - 10);
  }
  
  // Save the PDF
  const basicPdfFileName = `market-analysis-${commodityName.toLowerCase().replace(/\s+/g, '-')}-${new Date().toISOString().split('T')[0]}.pdf`;
  pdf.save(basicPdfFileName);
  
  return true;
};
