// Utility functions for price conversion and formatting

/**
 * Convert price based on unit
 * @param {number} pricePerKg - Price per kilogram
 * @param {string} unit - Target unit ('kg' or '100kg')
 * @returns {number} - Converted price
 */
export function convertPrice(pricePerKg, unit) {
  // Handle edge cases - ensure we have a valid number
  const price = parseFloat(pricePerKg);
  if (isNaN(price) || price === null || price === undefined) {
    return 0;
  }
  
  if (unit === '100kg') {
    return price * 100;
  }
  return price;
}

/**
 * Format price with proper unit display
 * @param {number} pricePerKg - Price per kilogram
 * @param {string} unit - Display unit ('kg' or '100kg')
 * @returns {string} - Formatted price string
 */
export function formatPriceWithUnit(pricePerKg, unit) {
  const convertedPrice = convertPrice(pricePerKg, unit);
  return `TSh ${convertedPrice.toLocaleString()}/${unit}`;
}

/**
 * Get unit display text
 * @param {string} unit - Unit ('kg' or '100kg')
 * @returns {string} - Display text
 */
export function getUnitDisplayText(unit) {
  return unit === '100kg' ? 'per 100kg' : 'per kg';
}

/**
 * Convert price value for chart display
 * @param {number} pricePerKg - Price per kilogram
 * @param {string} unit - Target unit ('kg' or '100kg')
 * @returns {number} - Converted price for chart
 */
export function convertPriceForChart(pricePerKg, unit) {
  return convertPrice(pricePerKg, unit);
}
