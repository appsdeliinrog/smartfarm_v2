const API_BASE_URL = 'http://127.0.0.1:8000/api';

export const api = {
  async get(endpoint) {
    const response = await fetch(`${API_BASE_URL}${endpoint}`);
    if (!response.ok) {
      throw new Error(`API error: ${response.status}`);
    }
    return response.json();
  },

  async post(endpoint, data) {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });
    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      const error = new Error(`API error: ${response.status}`);
      error.response = { data: errorData };
      throw error;
    }
    return response.json();
  },

  // Specific API endpoints
  async getCommodities() {
    return this.get('/commodities/');
  },

  async getRegions() {
    return this.get('/regions/');
  },

  async getMarkets() {
    return this.get('/markets/');
  },

  async getPriceObservations(params = {}) {
    const searchParams = new URLSearchParams(params);
    return this.get(`/price-observations/?${searchParams}`);
  },

  async getLatestPrices(params = {}) {
    const searchParams = new URLSearchParams(params);
    return this.get(`/price-observations/latest/?${searchParams}`);
  },

  async getPriceTrends(params = {}) {
    const searchParams = new URLSearchParams(params);
    return this.get(`/price-observations/trends/?${searchParams}`);
  },

  async getPriceSummary() {
    return this.get('/price-observations/summary/');
  },

  async getBestPrices(params = {}) {
    const searchParams = new URLSearchParams(params);
    return this.get(`/price-observations/best_prices/?${searchParams}`);
  },

  async compareMarkets(params = {}) {
    const searchParams = new URLSearchParams();
    
    // Handle the markets array parameter
    if (params.markets && Array.isArray(params.markets)) {
      params.markets.forEach(marketId => {
        searchParams.append('markets', marketId);
      });
    }
    
    // Add other parameters
    Object.keys(params).forEach(key => {
      if (key !== 'markets') {
        searchParams.append(key, params[key]);
      }
    });
    
    return this.get(`/price-observations/compare_markets/?${searchParams}`);
  }
};
